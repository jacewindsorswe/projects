﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Sprint0;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sprint2.Interfaces;

namespace Sprint2.Item_Classes.ItemStates
{
    public class OrangeTriangle : IItemState
    {
        //Direction property useless for this class
        public Item.Direction FrameDirection
        {
            get { return Item.Direction.Idle; }
            set { }
        }

        //Activity property useless for this class
        private bool active = true;
        public bool IsActive
        {
            get { return active; }
            set { active = value; }
        }

        //height and width of item (not the frame)
        private int width = (int)(11 * 2.5 * GlobalUtilities.Res_Scalar);
        private int height = (int)(11 * 2.5 * GlobalUtilities.Res_Scalar);

        public int Width
        {
            get { return width; }
            set { width = value; }
        }
        public int Height
        {
            get { return height; }
            set { height = value; }
        }

        //movement speed
        private readonly int speed = 0;
        public int Speed
        {
            get { return speed; }
        }

        //stores type of item
        private ItemStateMachine.ItemType frameType = ItemStateMachine.ItemType.OrangeTriangle;

        //x and y position
        private int x;
        private int y;

        private int count = 0;

        public int X
        {
            get { return x; }
            set { x = value; }
        }
        public int Y
        {
            get { return y; }
            set { y = value; }
        }

        //existence of item
        private bool existence = true;
        public bool Exists
        {
            get { return existence; }
            set { existence = value; }
        }

        //Damage field
        public int Damage
        {
            get { return 0; }
        }

        //Frame
        Rectangle frame;

        //Texture
        Texture2D texture;

        //Constructor
        public OrangeTriangle()
        {
            UpdateFrame();
        }

        //methods in interface
        public void Pickup()
        {
            existence = false;
        }

        public void Update(GameTime gT)
        {
            count++;
            if (count > GlobalUtilities.ITEM_ANIMATE_TIME)
            {
                if (frameType == ItemStateMachine.ItemType.OrangeTriangle)
                {
                    frameType = ItemStateMachine.ItemType.BlueTriangle;
                }
                else
                {
                    frameType = ItemStateMachine.ItemType.OrangeTriangle;
                }
                count = 0;
            }
            UpdateFrame();

        }
        public bool Update(GameTime gT, double cT, bool flip)
        {
            return false;
        }
        public void Draw(SpriteBatch spriteBatch, Color color)
        {
            Rectangle rect = new Rectangle(x, y, width, height);

            spriteBatch.Draw(texture, rect, frame, color);
        }

        public Rectangle GetHitbox()
        {
            return new Rectangle(x, y, width, height);
        }

        public void UpdateTexture(Texture2D text)
        {
            texture = text;
        }
        private void UpdateFrame()
        {
            int[] frameCoords = ItemSpriteFactory.ItemSpriteDictionary[frameType];
            frame = new Rectangle(frameCoords[0], frameCoords[1], frameCoords[2], frameCoords[3]);
        }
    }
}
