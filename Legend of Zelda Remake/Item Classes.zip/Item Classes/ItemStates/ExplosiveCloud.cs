﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Sprint0;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sprint2.Interfaces;

namespace Sprint2.Item_Classes.ItemStates
{
    public class ExplosiveCloud : IItemState
    {
        public const double SCALING_FACTOR = 5;

        public const int DEFAULT_WIDTH = (int)(10 * SCALING_FACTOR);
        public const int DEFAULT_HEIGHT = (int)(10 * SCALING_FACTOR);

        Item.Direction frameDirection;
        public Item.Direction FrameDirection
        {
            get { return frameDirection; }
            set 
            { 
                frameDirection = value;
            }
        }

        private double timeCreated;
        public double TimeCreated 
        {
            get { return timeCreated; }
            set { timeCreated = value; }
        }

        //Activity property useless for this class
        private bool active = true;
        public bool IsActive
        {
            get { return active; }
            set { active = value; }
        }

        //height and width of item (not the frame)
        private int width = (int)(DEFAULT_WIDTH * GlobalUtilities.Res_Scalar);
        private int height = (int)(DEFAULT_HEIGHT * GlobalUtilities.Res_Scalar);

        public int Width
        {
            get { return width; }
            set { width = value; }
        }
        public int Height
        {
            get { return height; }
            set { height = value; }
        }

        //movement speed
        private readonly int speed = 6;
        public int Speed
        {
            get { return speed; }
        }

        //Damage field
        public int Damage
        {
            get { return 5; }
        }

        //stores type of item
        private ItemStateMachine.ItemType frameType = ItemStateMachine.ItemType.ExplosiveCloud1;

        //x and y position
        private int x;
        private int y;

        public int X
        {
            get { return x; }
            set { x = value; }
        }
        public int Y
        {
            get { return y; }
            set { y = value; }
        }

        //existence of item
        private bool existence = true;
        public bool Exists
        {
            get { return existence; }
            set { existence = value; }
        }

        //Frame
        Rectangle frame;

        //Texture
        Texture2D texture;

        //Constructor
        public ExplosiveCloud()
        {
        }

        //methods in interface
        public void Pickup()
        {
            existence = false;
        }

        public void Update(GameTime gT)
        {
        }
        public bool Update(GameTime gT, double cT, bool flip)
        {
            if (gT.TotalGameTime.TotalSeconds - cT >= GlobalUtilities.disappearTime[Item.ItemCategory.ExplosiveCloud])
            {
                existence = false;
            }
            UpdateFrame(gT);
            return false;
        }
        public void Draw(SpriteBatch spriteBatch, Color color)
        {
            Rectangle rect = new Rectangle(x, y, width, height);

            spriteBatch.Draw(texture, rect, frame, color);
        }

        public Rectangle GetHitbox()
        {
            return new Rectangle(x, y, width, height);
        }

        public void UpdateTexture(Texture2D text)
        {
            texture = text;
        }
        private void UpdateFrame(GameTime gT)
        {
            if (gT.TotalGameTime.TotalSeconds - timeCreated <= GlobalUtilities.disappearTime[Item.ItemCategory.ExplosiveCloud] / 3.0)
            {
                frameType = ItemStateMachine.ItemType.ExplosiveCloud1;
            }
            else if (gT.TotalGameTime.TotalSeconds - timeCreated <= (GlobalUtilities.disappearTime[Item.ItemCategory.ExplosiveCloud] * 2.0) / 3.0)
            {
                frameType = ItemStateMachine.ItemType.ExplosiveCloud2;
            }
            else
            {
                frameType = ItemStateMachine.ItemType.ExplosiveCloud3;
            }

            frame = new Rectangle(ItemSpriteFactory.ItemSpriteDictionary[frameType][0], ItemSpriteFactory.ItemSpriteDictionary[frameType][1], ItemSpriteFactory.ItemSpriteDictionary[frameType][2], ItemSpriteFactory.ItemSpriteDictionary[frameType][3]);
        }
    }
}
