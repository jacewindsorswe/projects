﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Item_Classes.ItemStates
{
    public class Bomb : IItemState
    {
        //Direction property useless for this class
        public Item.Direction FrameDirection
        {
            get { return Item.Direction.Idle; }
            set { }
        }

        //Activity property useless for this class
        private bool active = true;
        public bool IsActive
        {
            get { return active; }
            set { active = value; }
        }

        //height and width of item (not the frame)
        private int width = (int)(30 * GlobalUtilities.Res_Scalar);
        private int height = (int)(40 * GlobalUtilities.Res_Scalar);

        public int Width
        {
            get { return width; }
            set { width = value; }
        }
        public int Height
        {
            get { return height; }
            set { height = value; }
        }

        //Damage field
        public int Damage
        {
            get { return 0; }
        }

        //movement speed
        private readonly int speed = 0;
        public int Speed
        {
            get { return speed; }
        }

        //used for tick counting
        private int count = 0;

        //stores type of item
        private ItemStateMachine.ItemType frameType = ItemStateMachine.ItemType.BombFrame1;

        //x and y position
        private int x;
        private int y;

        public int X
        {
            get { return x; }
            set { x = value; }
        }
        public int Y
        {
            get { return y; }
            set { y = value; }
        }

        //existence of item
        private bool existence = true;
        public bool Exists
        {
            get { return existence; }
            set { existence = value; }
        }

        //Frame
        Rectangle frame;

        //Texture
        Texture2D texture;

        //Constructor
        public Bomb()
        {
            UpdateFrame();
        }

        //methods in interface
        public void Pickup()
        {
            existence = false;
        }

        public void Update(GameTime gT)
        {
        }
        public bool Update(GameTime gT, double cT, bool flip)
        {

            if (gT.TotalGameTime.TotalSeconds - cT >= GlobalUtilities.BOMB_FRAME_UPDATE)
            {
                if (frameType == ItemStateMachine.ItemType.BombFrame1)
                {
                    frameType = ItemStateMachine.ItemType.BombFrame2;
                }
                else if (gT.TotalGameTime.TotalSeconds - cT >= GlobalUtilities.BOMB_FRAME_UPDATE * 2)
                {
                    frameType = ItemStateMachine.ItemType.BombFrame3;
                }
            }
            return false;
        }
        public void Draw(SpriteBatch spriteBatch, Color color)
        {
            Rectangle rect = new Rectangle(x, y, width, height);

            spriteBatch.Draw(texture, rect, frame, color);
        }

        public Rectangle GetHitbox()
        {
            return new Rectangle(x, y, width, height);
        }

        public void UpdateTexture(Texture2D text)
        {
            texture = text;
        }
        private void UpdateFrame()
        {
            int[] frameCoords = ItemSpriteFactory.ItemSpriteDictionary[frameType];
            frame = new Rectangle(frameCoords[0], frameCoords[1], frameCoords[2], frameCoords[3]);
        }
    }
}
