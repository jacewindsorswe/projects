﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Sprint0;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sprint2.Interfaces;

namespace Sprint2.Item_Classes.ItemStates
{
    public class OrangeParticle : IItemState
    {
        public const double SCALING_FACTOR = 3;

        public const int DEFAULT_WIDTH = (int)(8 * SCALING_FACTOR);
        public const int DEFAULT_HEIGHT = (int)(10 * SCALING_FACTOR);

        //Up --> Top Left Diagonal, Right --> Top Right Diagonal, Down --> Bottom Right Diagonal, Left --> Bottom Left Diagonal
        Item.Direction frameDirection;
        public Item.Direction FrameDirection
        {
            get { return frameDirection; }
            set 
            { 
                frameDirection = value;
                UpdateFrame();
            }
        }

        //Activity property useless for this class
        private bool active = true;
        public bool IsActive
        {
            get { return active; }
            set { active = value; }
        }

        //height and width of item (not the frame)
        private int width = (int)(DEFAULT_WIDTH * GlobalUtilities.Res_Scalar);
        private int height = (int)(DEFAULT_HEIGHT * GlobalUtilities.Res_Scalar);

        public int Width
        {
            get { return width; }
            set { width = value; }
        }
        public int Height
        {
            get { return height; }
            set { height = value; }
        }

        //movement speed
        private readonly int speed = 6;
        public int Speed
        {
            get { return speed; }
        }

        //Damage field
        public int Damage
        {
            get { return 5; }
        }

        //stores type of item
        private ItemStateMachine.ItemType frameType = ItemStateMachine.ItemType.OrangeParticleTL;

        //x and y position
        private int x;
        private int y;

        public int X
        {
            get { return x; }
            set { x = value; }
        }
        public int Y
        {
            get { return y; }
            set { y = value; }
        }

        //existence of item
        private bool existence = true;
        public bool Exists
        {
            get { return existence; }
            set { existence = value; }
        }

        //Frame
        Rectangle frame;

        //Texture
        Texture2D texture;

        //Frame counter for animation purposes
        private int count = 0;

        //Constructor
        public OrangeParticle()
        {
            UpdateFrame();
        }

        //methods in interface
        public void Pickup()
        {
            existence = false;
        }

        public void Update(GameTime gT)
        {
        }
        public bool Update(GameTime gT, double cT, bool flip)
        {
            count++;
            if (gT.TotalGameTime.TotalSeconds - cT >= GlobalUtilities.disappearTime[Item.ItemCategory.OrangeParticle])
            {
                existence = false;
            }
            if (count % GlobalUtilities.PARTICLE_ANIMATE_TIME == 0)
            {
                UpdateFrame();
            }
            return false;
        }
        public void Draw(SpriteBatch spriteBatch, Color color)
        {
            Rectangle rect = new Rectangle(x, y, width, height);

            spriteBatch.Draw(texture, rect, frame, color);
        }

        public Rectangle GetHitbox()
        {
            return new Rectangle(x, y, width, height);
        }

        public void UpdateTexture(Texture2D text)
        {
            texture = text;
        }
        private void UpdateFrame()
        {
            frameType = GetDirectionFrame();
            int[] frameCoords = ItemSpriteFactory.ItemSpriteDictionary[frameType];
            frame = new Rectangle(frameCoords[0], frameCoords[1], frameCoords[2], frameCoords[3]);
        }

        //Up --> Top Left Diagonal, Right --> Top Right Diagonal, Down --> Bottom Right Diagonal, Left --> Bottom Left Diagonal
        private ItemStateMachine.ItemType GetDirectionFrame()
        {
            switch (frameDirection)
            {
                case Item.Direction.Down:
                    if (frameType != ItemStateMachine.ItemType.OrangeParticleBR)
                    {
                        return ItemStateMachine.ItemType.OrangeParticleBR;
                    }
                    else
                    {
                        return ItemStateMachine.ItemType.WhiteParticleBR;
                    }
                case Item.Direction.Up:
                    if (frameType != ItemStateMachine.ItemType.OrangeParticleTL)
                    {
                        return ItemStateMachine.ItemType.OrangeParticleTL;
                    }
                    else
                    {
                        return ItemStateMachine.ItemType.WhiteParticleTL;
                    }
                case Item.Direction.Left:
                    if (frameType != ItemStateMachine.ItemType.OrangeParticleBL)
                    {
                        return ItemStateMachine.ItemType.OrangeParticleBL;
                    }
                    else
                    {
                        return ItemStateMachine.ItemType.WhiteParticleBL;
                    }
                default:
                    if (frameType != ItemStateMachine.ItemType.OrangeParticleTR)
                    {
                        return ItemStateMachine.ItemType.OrangeParticleTR;
                    }
                    else
                    {
                        return ItemStateMachine.ItemType.WhiteParticleTR;
                    }
            }
        }
    }
}
