﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Item_Classes.ItemStates
{
    public class Fireball : IItemState
    {
        //Direction property useless for this class
        public Item.Direction FrameDirection
        {
            get { return Item.Direction.Idle; }
            set { }
        }

        //Activity property useless for this class
        private bool active = true;
        public bool IsActive
        {
            get { return active; }
            set { active = value; }
        }

        //height and width of item (not the frame)
        private int width = (int)(45 * GlobalUtilities.Res_Scalar);
        private int height = (int)(45 * GlobalUtilities.Res_Scalar);

        public int Width
        {
            get { return width; }
            set { width = value; }
        }
        public int Height
        {
            get { return height; }
            set { height = value; }
        }

        //movement speed
        private readonly int speed = 7;
        public int Speed
        {
            get { return speed; }
        }

        //used for tick counting
        private int count = 0;

        //stores type of item
        private ItemStateMachine.ItemType frameType = ItemStateMachine.ItemType.FireFrame1;

        //x and y position
        private int x;
        private int y;

        public int X
        {
            get { return x; }
            set { x = value; }
        }
        public int Y
        {
            get { return y; }
            set { y = value; }
        }

        //existence of item
        private bool existence = true;
        public bool Exists
        {
            get { return existence; }
            set { existence = value; }
        }

        //Damage field
        public int Damage
        {
            get { return 15; }
        }

        //Frame
        Rectangle frame;

        //Texture
        Texture2D texture;

        //Constructor
        public Fireball()
        {
            UpdateFrame();
        }

        //methods in interface
        public void Pickup()
        {
            existence = false;
        }

        public void Update(GameTime gT)
        {
            count++;
            if (count > GlobalUtilities.FIRE_ANIMATE_TIME)
            {
                if (frameType == ItemStateMachine.ItemType.FireFrame1)
                {
                    frameType = ItemStateMachine.ItemType.FireFrame2;
                }
                else
                {
                    frameType = ItemStateMachine.ItemType.FireFrame1;
                }
                count = 0;
            }
            UpdateFrame();
        }
        public bool Update(GameTime gT, double cT, bool flip)
        {
            Update(gT);
            return false;
        }
        public void Draw(SpriteBatch spriteBatch, Color color)
        {
            Rectangle rect = new Rectangle(x, y, width, height);
            spriteBatch.Draw(texture, rect, frame, color);
        }

        public Rectangle GetHitbox()
        {
            return new Rectangle(x, y, width, height);
        }

        public void UpdateTexture(Texture2D text)
        {
            texture = text;
        }
        private void UpdateFrame()
        {
            int[] frameCoords = ItemSpriteFactory.ItemSpriteDictionary[frameType];
            frame = new Rectangle(frameCoords[0], frameCoords[1], frameCoords[2], frameCoords[3]);
        }
    }
}
