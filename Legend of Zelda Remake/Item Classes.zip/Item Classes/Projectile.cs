﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Sprint2;
using Sprint2.Interfaces;
using Sprint2.Item_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class Projectile : CollidableObject
    {
        private Item item;

        private static SortedDictionary<int, Projectile> projectiles = new SortedDictionary<int, Projectile>();
        private static List<Projectile> projList = new List<Projectile>();

        public static SortedDictionary<int, Projectile> ProjectileDictionary 
        {
            get { return projectiles; }
        }
        public static void RemoveProjectile(int key)
        {
            projectiles.Remove(key);
            Item.RemoveItem(key);
        }
        public static List<Projectile> ProjectileList
        {
            get
            {
                projList.Clear();
                foreach (KeyValuePair<int, Projectile> pair in projectiles)
                {
                    projList.Add(pair.Value);
                }
                return projList;
            }
        }

        private bool active = true;
        public bool IsActive 
        {
            get { return active; }
            set { active = value; }
        }

        public int ID 
        {
            get { return item.ID; }
        }

        //Records when an item was spawned
        private double callTime;
        public double CallTime
        {
            get { return callTime; }
            set { callTime = value; }
        }

        //Stores whether Link threw the projectile (for immunity)
        private bool linkThrew = false;
        public bool LinkThrow 
        {
            get { return linkThrew; }
            set { linkThrew = value; }
        }

        //Gets damage amount
        public int Damage 
        {
            get { return item.Damage; }
        }

        //Flipped boolean used for boomerang
        private bool flipped = true;
        public bool Flipped 
        {
            get { return flipped; }
            set { flipped = value; }
        }

        //Methods to access ItemStateMachine stuff
        public Item State
        {
            get { return item; }
        }
        public Item.Direction MovementDirection
        {
            get { return item.MovementDirection; }
            set { item.MovementDirection = value; }
        }

        //Constructors
        public Projectile(Item it, double cT, int x, int y)
        {
            item = it;
            item.X = x;
            item.Y = y;
            callTime = cT;

            it.CollidableType = CollidableObject.Type.Projectile;

            projectiles.Add(ID, this);
        }

        //These methods access specific state information
        public bool Exists
        {
            get { return item.Exists; }
            set 
            { 
                item.Exists = value;
                if (!value)
                {
                    projectiles.Remove(ID);
                }
            }
        }
        public int X
        {
            get { return item.X; }
            set { item.X = value; }
        }
        public int Y
        {
            get { return item.Y; }
            set { item.Y = value; }
        }
        public int Width
        {
            get { return item.Width; }
            set
            {
                item.Width = value;
            }
        }
        public int Height { get { return item.Height; } set { item.Height = value; } }

        public Item.ItemCategory ItemClass 
        {
            get { return item.ItemClass; }
            set { item.ItemClass = value; }
        }

        public void Pickup()
        {
            Exists = false;
            item.Pickup();
        }
        public void Update(GameTime gT)
        {
            bool flip = item.Update(gT, callTime, flipped);
            if (flip && (item.ItemClass == Item.ItemCategory.Boomerang || item.ItemClass == Item.ItemCategory.BlueBoomerang)) 
            {
                flipped = true;
                ChangeDirection(item.MovementDirection);
            }

            if (item.ItemClass == Item.ItemCategory.OrangeParticle)
            {
                MoveDiagonal();
            }
            else if(item.ItemClass != Item.ItemCategory.ExplosiveCloud)
            {
                Move();
            }
        }


        public void Draw(SpriteBatch spriteBatch, Color color)
        {
            item.Draw(spriteBatch, color);
        }

        //Movement logic
        //Manual speed
        public void Move(int speed)
        {
            item.Move(speed);
        }
        //Object speed
        public void Move()
        {
            item.Move();
        }

        //Manual speed
        public void MoveDiagonal(int speed) 
        {
            item.MoveDiagonal(speed);
        }
        public void MoveDiagonal() 
        {
            item.MoveDiagonal();
        }

        public void ChangeDirection(Item.Direction direction)
        {
            switch (direction)
            {
                case Item.Direction.Up:
                    item.MovementDirection = Item.Direction.Down;
                    break;
                case Item.Direction.Down:
                    item.MovementDirection = Item.Direction.Up;
                    break;
                case Item.Direction.Left:
                    item.MovementDirection = Item.Direction.Right;
                    break;
                case Item.Direction.Right:
                    item.MovementDirection = Item.Direction.Left;
                    break;
                case Item.Direction.UpLeft:
                    item.MovementDirection = Item.Direction.UpLeft;
                    break;
                case Item.Direction.DownLeft:
                    item.MovementDirection = Item.Direction.DownLeft;
                    break;
                case Item.Direction.UpRight:
                    item.MovementDirection = Item.Direction.UpRight;
                    break;
                case Item.Direction.DownRight:
                    item.MovementDirection = Item.Direction.DownRight;
                    break;
            }
        }

        public void SetFrameDirection(Item.Direction direct) 
        {
            item.FrameDirection = direct;
        }

        public object Clone()
        {
            return new Projectile(item, callTime, X, Y);
        }

        //Collision handling
        public CollidableObject.Type CollidableType
        {
            get { return item.CollidableType; }
            set { item.CollidableType = value; }
        }
        public Rectangle CurrentHitbox
        {
            get
            {
                return item.CurrentHitbox;
            }
            set
            {
                item.CurrentHitbox = value;
            }
        }
    }
}
