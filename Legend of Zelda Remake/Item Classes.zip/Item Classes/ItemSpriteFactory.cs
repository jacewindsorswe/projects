﻿using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Sprint2.Item_Classes;
using Sprint2.Item_Classes.ItemStates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Sprint2.Enemy_Classes.DeathAnimation;
using static System.Net.Mime.MediaTypeNames;

namespace Sprint0
{
    public class ItemSpriteFactory
    {

        private Texture2D itemSpriteSheet;
        private Texture2D fireSpriteSheet;
        private Texture2D boomerangSpriteSheet;
        private Texture2D dragonFireSpriteSheet;
        private Texture2D blueBoomerang;

        public static ItemSpriteFactory instance = new ItemSpriteFactory();
        public static ItemSpriteFactory Instance
        {
            get
            {
                return instance;
            }
        }

        private ItemSpriteFactory()
        {}

        public void LoadAllTextures(ContentManager content)
        {
            itemSpriteSheet = content.Load<Texture2D>("link");
            fireSpriteSheet = content.Load<Texture2D>("fire sprite sheet");
            boomerangSpriteSheet = content.Load<Texture2D>("boomerang");
            dragonFireSpriteSheet = content.Load<Texture2D>("Bosses");
            deathSpriteSheet = content.Load<Texture2D>("deathanimations");
            blueBoomerang = content.Load<Texture2D>("blueboomerang");
        }

        //Used to keep track of frame info for other classes
        public static readonly Dictionary<ItemStateMachine.ItemType, int[]> ItemSpriteDictionary = new Dictionary<ItemStateMachine.ItemType, int[]>()
        {
            { ItemStateMachine.ItemType.RupeeFrame1, new int[] {244, 225, 8, 16 } },
            { ItemStateMachine.ItemType.RupeeFrame2, new int[] { 274, 225, 8, 16 } },
            { ItemStateMachine.ItemType.FireFrame1, new int[] {712, 337, 437, 437 } },
            { ItemStateMachine.ItemType.FireFrame2, new int[] { 1151, 337, 437, 437 } },
            { ItemStateMachine.ItemType.Clock, new int[] { 392, 165, 11, 16 } },
            { ItemStateMachine.ItemType.SmallHeart1, new int[] { 244, 199, 7, 8 } },
            { ItemStateMachine.ItemType.SmallHeart2, new int[] { 274, 199, 7, 8 } },
            { ItemStateMachine.ItemType.BigHeart, new int[] { 301, 196, 13, 13 } },
            { ItemStateMachine.ItemType.Key, new int[] { 364, 255, 8, 16 } },
            { ItemStateMachine.ItemType.RedPotion, new int[] { 394, 285, 8, 16 } },
            { ItemStateMachine.ItemType.BluePotion, new int[] { 424, 285, 8, 16 } },
            { ItemStateMachine.ItemType.Bow, new int[] { 424, 255, 8, 16 } },
            { ItemStateMachine.ItemType.LeftArrow, new int[] { 150, 200, 16, 5 } },
            { ItemStateMachine.ItemType.RightArrow, new int[] { 210, 200, 16, 5 } },
            { ItemStateMachine.ItemType.UpArrow, new int[] { 185, 195, 5, 16 } },
            { ItemStateMachine.ItemType.DownArrow, new int[] { 125, 195, 5, 16 } },
            { ItemStateMachine.ItemType.BombFrame1, new int[] { 364, 226, 8, 14 } },
            { ItemStateMachine.ItemType.BombFrame2, new int[] { 149, 282, 17, 21 } },
            { ItemStateMachine.ItemType.BombFrame3, new int[] { 179, 282, 17, 21 } },
            { ItemStateMachine.ItemType.DragonFireFrame1, new int[] { 119, 11, 8, 16 } },
            { ItemStateMachine.ItemType.DragonFireFrame2, new int[] { 110, 11, 8, 16 } },
            { ItemStateMachine.ItemType.DragonFireFrame3, new int[] { 101, 11, 8, 16 } },
            { ItemStateMachine.ItemType.BoomerangFrame1, new int[] { 0, 0, 5, 8 } },
            { ItemStateMachine.ItemType.BoomerangFrame2, new int[] { 6, 0, 8, 5 } },
            { ItemStateMachine.ItemType.BoomerangFrame3, new int[] { 15, 0, 5, 8 } },
            { ItemStateMachine.ItemType.BoomerangFrame4, new int[] { 21, 0, 8, 5 } },
            { ItemStateMachine.ItemType.BlueBoomerangFrame1, new int[] { 0, 0, 5, 8 } },
            { ItemStateMachine.ItemType.BlueBoomerangFrame2, new int[] { 6, 0, 8, 5 } },
            { ItemStateMachine.ItemType.BlueBoomerangFrame3, new int[] { 15, 0, 5, 8 } },
            { ItemStateMachine.ItemType.BlueBoomerangFrame4, new int[] { 21, 0, 8, 5 } },
            { ItemStateMachine.ItemType.SwordDown, new int[] { 4, 195, 7, 16 } },
            { ItemStateMachine.ItemType.SwordLeft, new int[] { 30, 199, 16, 7 } },
            { ItemStateMachine.ItemType.SwordRight, new int[] { 90, 199, 16, 7 } },
            { ItemStateMachine.ItemType.SwordUp, new int[] { 64, 195, 7, 16 } },
            { ItemStateMachine.ItemType.SwordDownProj, new int[] { 4, 225, 7, 16 } },
            { ItemStateMachine.ItemType.SwordLeftProj, new int[] { 30, 229, 16, 7 } },
            { ItemStateMachine.ItemType.SwordRightProj, new int[] { 90, 229, 16, 7 } },
            { ItemStateMachine.ItemType.SwordUpProj, new int[] { 64, 225, 7, 16 } },
            { ItemStateMachine.ItemType.SwordDownProjFrame2, new int[] { 4, 285, 7, 16 } },
            { ItemStateMachine.ItemType.SwordLeftProjFrame2, new int[] { 30, 289, 16, 7 } },
            { ItemStateMachine.ItemType.SwordRightProjFrame2, new int[] { 90, 289, 16, 7 } },
            { ItemStateMachine.ItemType.SwordUpProjFrame2, new int[] { 64, 285, 7, 16 } },
            { ItemStateMachine.ItemType.OrangeParticleTL, new int[] { 179, 282, 8, 10 } },
            { ItemStateMachine.ItemType.OrangeParticleTR, new int[] { 188, 282, 8, 10 } },
            { ItemStateMachine.ItemType.OrangeParticleBL, new int[] { 179, 293, 8, 10 } },
            { ItemStateMachine.ItemType.OrangeParticleBR, new int[] { 188, 293, 8, 10 } },
            { ItemStateMachine.ItemType.WhiteParticleTL, new int[] { 209, 282, 8, 10 } },
            { ItemStateMachine.ItemType.WhiteParticleTR, new int[] { 218, 282, 8, 10 } },
            { ItemStateMachine.ItemType.WhiteParticleBL, new int[] { 209, 293, 8, 10 } },
            { ItemStateMachine.ItemType.WhiteParticleBR, new int[] { 218, 293, 8, 10 } },
            { ItemStateMachine.ItemType.GoldenTicket, new int[] { 272, 254, 10, 16 } },
            { ItemStateMachine.ItemType.Compass, new int[] { 390, 256, 13, 14 } },
            { ItemStateMachine.ItemType.OrangeTriangle, new int[] { 331, 288, 12, 10 } },
            { ItemStateMachine.ItemType.BlueTriangle, new int[] { 363, 288, 12, 10 } },
            { ItemStateMachine.ItemType.ExplosiveCloud1, new int[] { 22, 2, 16, 16 } },
            { ItemStateMachine.ItemType.ExplosiveCloud2, new int[] { 44, 2, 16, 16 } },
            { ItemStateMachine.ItemType.ExplosiveCloud3, new int[] { 44, 22, 16, 16 } },
        };

        public Item CreateItem(Item.ItemCategory iT, int startX, int startY)
        {
            Texture2D text = GetTexture(iT);
            return new Item(GetTexture(iT), iT, startX, startY);
        }

        private Texture2D GetTexture(Item.ItemCategory type) 
        {
            switch (type) 
            {
                case Item.ItemCategory.Fire:
                    return fireSpriteSheet;
                case Item.ItemCategory.Boomerang:
                    return boomerangSpriteSheet;
                case Item.ItemCategory.DragonFire:
                    return dragonFireSpriteSheet;
                case Item.ItemCategory.ExplosiveCloud:
                    return deathSpriteSheet;
                case Item.ItemCategory.BlueBoomerang:
                    return blueBoomerang;
                default:
                    return itemSpriteSheet;
            }
        }


    }
}
