﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Item_Classes.ItemStates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Item_Classes
{
    public class Explosion
    {
        //These two variables change the size of the explosion radius--the large the horizontal offset, the more spread out horizontally
        //(and the same for vertical offset but vertically)

        //If both 0, the explosion will start within the bounds of the exploding item/projectile
        public const int HORIZONTAL_OFFSET = 0;
        public const int VERTICAL_OFFSET = 0;

        //The larger the offset, the larger the radius of potential explosions for the bomb
        public const int B_HORIZONTAL_OFFSET = 20;
        public const int B_VERTICAL_OFFSET = 20;

        private int lX, uY, rX, dY;
        public int RX { get { return rX; } set { rX = value; } }
        public int DY { get { return dY; } set { dY = value; } }
        public int LX { get { return lX; } set { lX = value; } }
        public int UY { get { return uY; } set { uY = value; } }

        private List<Projectile> particles = new List<Projectile>();
        public List<Projectile> ParticleList 
        {
            get { return particles; }
        }

        private Dictionary<int, Item.Direction> facingDirection = new Dictionary<int, Item.Direction>()
        {
            { 0, Item.Direction.Up },
            { 1, Item.Direction.Right },
            { 2, Item.Direction.Left },
            { 3, Item.Direction.Down }
        };

        public Explosion(Item.ItemCategory explosiveType, int rightX, int downY, int leftX, int upY, GameTime gT)
        {
            double recordedTime = gT.TotalGameTime.TotalSeconds;
            switch (explosiveType)
            {
                case Item.ItemCategory.OrangeParticle:
                    RX = rightX + HORIZONTAL_OFFSET;
                    LX = leftX - HORIZONTAL_OFFSET;
                    UY = upY - VERTICAL_OFFSET;
                    DY = downY + VERTICAL_OFFSET;

                    for (int i = 0; i < 4; i++)
                    {
                        int[] position = GetParticlePosition(Item.ItemCategory.OrangeParticle, i);
                        Item item = ItemSpriteFactory.Instance.CreateItem(explosiveType, position[0], position[1]);
                        Projectile proj = new Projectile(item, recordedTime, position[0], position[1]);

                        proj.SetFrameDirection(facingDirection[i]);
                        proj.MovementDirection = facingDirection[i];

                        particles.Add(proj);
                    }
                    break;
                case Item.ItemCategory.ExplosiveCloud:
                    LX = leftX - B_HORIZONTAL_OFFSET;
                    RX = rightX + B_HORIZONTAL_OFFSET;
                    UY = upY - B_VERTICAL_OFFSET;
                    DY = downY + B_VERTICAL_OFFSET;

                    for (int i = 0; i < GlobalUtilities.NUMBER_EXPLOSIONS; i++)
                    {
                        int[] position = GetParticlePosition(Item.ItemCategory.ExplosiveCloud, i);
                        Item item = ItemSpriteFactory.Instance.CreateItem(explosiveType, position[0], position[1]);
                        ((ExplosiveCloud)item.State).TimeCreated = gT.TotalGameTime.TotalSeconds;
                        Projectile proj = new Projectile(item, recordedTime, position[0], position[1]);

                        //proj.SetFrameDirection(facingDirection[i]);
                        //proj.MovementDirection = facingDirection[i];

                        particles.Add(proj);
                    }
                    break;
            }

            

        }

        private int[] GetParticlePosition(Item.ItemCategory itemCat, int i)
        {
            switch (itemCat)
            {
                case Item.ItemCategory.OrangeParticle:
                    switch (i)
                    {
                        case 0:
                            return new int[] { LX, UY };
                        case 1:
                            return new int[] { RX - OrangeParticle.DEFAULT_WIDTH, UY };
                        case 2:
                            return new int[] { LX, DY - OrangeParticle.DEFAULT_HEIGHT };
                        case 3:
                            return new int[] { RX - OrangeParticle.DEFAULT_WIDTH, DY - OrangeParticle.DEFAULT_HEIGHT };
                        default:
                            return new int[] { RX - OrangeParticle.DEFAULT_WIDTH, DY - OrangeParticle.DEFAULT_HEIGHT };
                    }
                default:
                    return new int[] { RandomNumberGenerator.GetInt32(LX, RX), RandomNumberGenerator.GetInt32(UY, DY) };
            }
        }
    }
}
