﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Sprint0;
using Sprint2.Interfaces;
using Sprint2.Item_Classes.ItemStates;
using Sprint2.Item_Classes.ItemStates.Arrows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Item_Classes
{
    public class Item : CollidableObject
    {
        public static int numItems = 0;
        private int itemID;
        public int ID 
        {
            get { return itemID; }
        }

        private static SortedDictionary<int, Item> items = new SortedDictionary<int, Item>();
        private static List<Item> itemList = new List<Item>();
        ItemStateMachine StateMachine;

        public static SortedDictionary<int, Item> ItemDictionary
        {
            get { return items; }
        }
        public static void RemoveItem(int key)
        {
            items.Remove(key);
        }

        public static List<Item> ItemList
        {
            get
            {
                itemList.Clear();
                foreach (KeyValuePair<int, Item> pair in items)
                {
                    itemList.Add(pair.Value);
                }
                return itemList;
            }
        }

        public enum ItemCategory 
        {
            Rupee,
            Key,
            SmallHeart,
            BigHeart,
            Bow,
            Fire,
            Boomerang,
            UpArrow,
            DownArrow,
            LeftArrow,
            RightArrow,
            Bomb,
            Clock,
            Sword,
            UpSwordProj,
            DownSwordProj,
            LeftSwordProj,
            RightSwordProj,
            OrangeParticle,
            DragonFire,
            GoldenTicket,
            Compass,
            OrangeTriangle,
            ExplosiveCloud,
            BlueBoomerang
        }

        private Dictionary<ItemCategory, IItemState> possibleStates = new Dictionary<ItemCategory, IItemState>() 
        {
            { ItemCategory.Rupee, new Rupee() },
            { ItemCategory.Key, new ItemKey() },
            { ItemCategory.Bomb, new Bomb() },
            { ItemCategory.Fire, new Fireball() },
            { ItemCategory.Clock, new Clock() },
            { ItemCategory.Boomerang, new Boomerang() },
            { ItemCategory.BlueBoomerang, new BlueBoomerang() },
            { ItemCategory.DownArrow, new DownArrow() },
            { ItemCategory.UpArrow, new UpArrow() },
            { ItemCategory.LeftArrow, new LeftArrow() },
            { ItemCategory.RightArrow, new RightArrow() },
            { ItemCategory.Bow, new Bow() },
            { ItemCategory.SmallHeart, new SmallHeart() },
            { ItemCategory.BigHeart, new BigHeart() },
            { ItemCategory.Sword, new Sword() },
            { ItemCategory.UpSwordProj, new UpSwordProj() },
            { ItemCategory.DownSwordProj, new DownSwordProj() },
            { ItemCategory.LeftSwordProj, new LeftSwordProj() },
            { ItemCategory.RightSwordProj, new RightSwordProj() },
            { ItemCategory.OrangeParticle, new OrangeParticle() },
            { ItemCategory.ExplosiveCloud, new ExplosiveCloud() },
            { ItemCategory.DragonFire, new DragonFire() },
            { ItemCategory.GoldenTicket, new GoldenTicket() },
            { ItemCategory.Compass, new Compass() },
            { ItemCategory.OrangeTriangle, new OrangeTriangle() },
        };

        private readonly IItemState state;
        public IItemState State 
        {
            get { return state; }
        }

        private ItemCategory itemClass;
        public ItemCategory ItemClass 
        {
            get 
            {
                return itemClass;
            }
            set 
            {
                itemClass = value;
            }
        }

        public int Damage 
        {
            get 
            {
                if (GlobalUtilities.projectileDamage.ContainsKey(itemClass))
                {
                    return GlobalUtilities.projectileDamage[itemClass];
                }
                return 0;
            }
        }

        public Direction FrameDirection 
        {
            get { return state.FrameDirection; }
            set { state.FrameDirection = value; }
        }

        public bool IsActive 
        {
            get 
            { 
                return state.IsActive; 
            }
            set 
            { 
                state.IsActive = value;
            }
        }

        public enum Direction 
        {
            Left,
            Right,
            Up,
            Down,
            UpLeft,
            DownLeft,
            UpRight,
            DownRight,
            Idle
        }
        private Direction direction = Direction.Idle;
        public Direction MovementDirection 
        {
            get { return direction; }
            set { direction = value; }
        }

        //Constructors
        public Item(Texture2D texture, ItemCategory type, int startX, int startY, int startW, int startH) : this(texture, type, startX, startY)
        {
            Width = startW;
            Height = startH;

            StateMachine = new ItemStateMachine(this);
        }
        public Item(Texture2D texture, ItemCategory type, int startX, int startY)
        {
            numItems++;
            itemID = numItems;

            collidableType = CollidableObject.Type.Item;

            state = possibleStates[type];
            state.UpdateTexture(texture);

            itemClass = type;

            X = startX;
            Y = startY;

            items.Add(ID, this);

            StateMachine = new ItemStateMachine(this);
        }

        //These methods access specific state information
        public bool Exists 
        {
            get { return state.Exists; }
            set 
            { 
                state.Exists = value;
                if (!state.Exists) 
                {
                    items.Remove(ID);
                }
            }
        }
        public int X 
        {
            get { return state.X; }
            set { state.X = value; }
        }
        public int Y 
        {
            get { return state.Y; }
            set { state.Y = value; }
        }
        public int Width 
        {
            get { return state.Width; }
            set
            {
                state.Width = value;
            }
        }
        public int Height { get { return state.Height; } set { state.Height = value; } }

        public void Pickup() 
        {
            StateMachine.Pickup();
        }
        //Non-projectile update
        public void Update(GameTime gT) 
        {
            state.Update(gT);
        }
        /*public void Update(GameTime gameTime)
        {

        }*/
        //Projectile update
        public bool Update(GameTime gT, double cT, bool flipped)
        {
            return state.Update(gT, cT, flipped);
        }
        public void Draw(SpriteBatch spriteBatch, Color color) 
        {
            state.Draw(spriteBatch, color);
        }

        //Movement logic
        //Manual speed
        public void Move(int speed) 
        {
            StateMachine.Move(speed, direction);
        }
        //Object speed
        public void Move()
        {
            StateMachine.Move(direction);
            
        }

        //Up --> Top Left Diagonal, Right --> Top Right Diagonal, Down --> Bottom Right Diagonal, Left --> Bottom Left Diagonal
        public void MoveDiagonal(int speed)
        {
            StateMachine.MoveDiagonal(speed, direction);
        }
        public void MoveDiagonal()
        {
            StateMachine.MoveDiagonal(direction);
        }

        public object Clone()
        {
            return ItemSpriteFactory.Instance.CreateItem(itemClass, X, Y);
        }

        //Collision Handling
        public CollidableObject.Type collidableType;
        public CollidableObject.Type CollidableType 
        {
            get { return collidableType; }
            set { collidableType = value; }
        }
        public Rectangle CurrentHitbox 
        {
            get
            {
                return state.GetHitbox();
            }
            set
            {
                state.Width = value.Width;
                state.Height = value.Height;
                state.X = value.X;
                state.Y = value.Y;
            }
        }

        /*private CollisionDetector.CollisionType collisionType = CollisionDetector.CollisionType.None;
        public CollisionDetector.CollisionType CurrentCollisionType
        {
            get { return collisionType; }
            set { collisionType = value; }
        }*/
    }
}
