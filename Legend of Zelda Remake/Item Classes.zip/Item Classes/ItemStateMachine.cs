﻿using Sprint2.Interfaces;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Item_Classes
{
    public class ItemStateMachine
    {

        Item item;
        IItemState state;
        int x;
        int y;

        public ItemStateMachine(Item i)
        {
            item = i;
            state = i.State;
            x = i.X;
            y = i.Y;
        }

        public enum ItemType
        {

            RupeeFrame1,
            RupeeFrame2,
            FireFrame1,
            FireFrame2,
            Clock,
            SmallHeart1,
            SmallHeart2,
            BigHeart,
            Key,
            RedPotion,
            BluePotion,
            Bow,
            LeftArrow,
            RightArrow,
            UpArrow,
            DownArrow,
            BombFrame1,
            BombFrame2,
            BombFrame3,
            DragonFireFrame1,
            DragonFireFrame2,
            DragonFireFrame3,
            BoomerangFrame1,
            BoomerangFrame2,
            BoomerangFrame3,
            BoomerangFrame4,
            BlueBoomerangFrame1,
            BlueBoomerangFrame2,
            BlueBoomerangFrame3,
            BlueBoomerangFrame4,
            SwordLeft,
            SwordRight,
            SwordUp,
            SwordDown,
            SwordLeftProj,
            SwordRightProj,
            SwordUpProj,
            SwordDownProj,
            SwordLeftProjFrame2,
            SwordRightProjFrame2,
            SwordUpProjFrame2,
            SwordDownProjFrame2,
            OrangeParticleTL,
            OrangeParticleTR,
            OrangeParticleBL,
            OrangeParticleBR,
            WhiteParticleTL,
            WhiteParticleTR,
            WhiteParticleBL,
            WhiteParticleBR,
            GoldenTicket,
            Compass,
            OrangeTriangle,
            BlueTriangle,
            ExplosiveCloud1,
            ExplosiveCloud2,
            ExplosiveCloud3
        }

        public int X
        {
            get { return x; }
            set { x = value; }
        }

        public int Y
        {
            get { return y; }
            set { y = value; }
        }

        public void Move(int speed, Item.Direction direction)
        {
            switch (direction)
            {
                case Item.Direction.Left:
                    MoveLeft(speed);
                    break;
                case Item.Direction.Right:
                    MoveRight(speed);
                    break;
                case Item.Direction.Up:
                    MoveUp(speed);
                    break;
                case Item.Direction.Down:
                    MoveDown(speed);
                    break;
                default:
                    break;
            }
        }
        //Object speed
        public void Move(Item.Direction direction)
        {
            switch (direction)
            {
                case Item.Direction.Left:
                    MoveLeft(state.Speed);
                    break;
                case Item.Direction.Right:
                    MoveRight(state.Speed);
                    break;
                case Item.Direction.Up:
                    MoveUp(state.Speed);
                    break;
                case Item.Direction.Down:
                    MoveDown(state.Speed);
                    break;
                case Item.Direction.UpLeft:
                    MoveUp(state.Speed * 2 / 3);
                    MoveLeft(state.Speed * 2 / 3);
                    break;
                case Item.Direction.DownLeft:
                    MoveDown(state.Speed * 2 / 3);
                    MoveLeft(state.Speed * 2 / 3);
                    break;
                default:
                    break;
            }

        }

        //Up --> Top Left Diagonal, Right --> Top Right Diagonal, Down --> Bottom Right Diagonal, Left --> Bottom Left Diagonal
        public void MoveDiagonal(int speed, Item.Direction direction)
        {
            switch (direction)
            {
                case Item.Direction.Left:
                    MoveLeft(speed / 2);
                    MoveDown(speed / 2);
                    break;
                case Item.Direction.Right:
                    MoveRight(speed / 2);
                    MoveUp(speed / 2);
                    break;
                case Item.Direction.Up:
                    MoveUp(speed / 2);
                    MoveLeft(speed / 2);
                    break;
                case Item.Direction.Down:
                    MoveDown(speed / 2);
                    MoveRight(speed / 2);
                    break;
                default:
                    break;
            }
        }
        public void MoveDiagonal(Item.Direction direction)
        {
            switch (direction)
            {
                case Item.Direction.Left:
                    MoveLeft(state.Speed / 2);
                    MoveDown(state.Speed / 2);
                    break;
                case Item.Direction.Right:
                    MoveRight(state.Speed / 2);
                    MoveUp(state.Speed / 2);
                    break;
                case Item.Direction.Up:
                    MoveUp(state.Speed / 2);
                    MoveLeft(state.Speed / 2);
                    break;
                case Item.Direction.Down:
                    MoveDown(state.Speed / 2);
                    MoveRight(state.Speed / 2);
                    break;
                default:
                    break;
            }
        }
        public void MoveLeft(int numPixels)
        {
            item.X -= numPixels;
            
        }
        public void MoveRight(int numPixels)
        {
            item.X += numPixels;
            
        }
        public void MoveUp(int numPixels)
        {
            item.Y -= numPixels;
            
        }
        public void MoveDown(int numPixels)
        {
            item.Y += numPixels;
        }

        public void Pickup()
        {
            state.Pickup();
            item.Exists = false;
        }
    }
}
