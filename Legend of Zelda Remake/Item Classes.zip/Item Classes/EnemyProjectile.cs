﻿using Microsoft.Xna.Framework;
using Sprint2.Item_Classes;
using Sprint2.Item_Classes.ItemStates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class EnemyProjectile
    {

        int x;
        int y;
        Enemy enemy;
        Enemy.Direction direction;
        Projectile boomerangProj;
        Projectile fireBallProjMid;
        Projectile fireBallProjTop;
        Projectile fireBallProjBot;
        Game1 game;

        public EnemyProjectile(Enemy e, Game1 g)
        {
            enemy = e;
            x = e.CurrentPosX;
            y = e.CurrentPosY;
            direction = e.CurrentDirection;
            game = g;
        }

        public void throwBoomerang(GameTime gameTime)
        {
            Item boomerang = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.Boomerang, x, y);
            
            switch (direction)
            {
                case (Enemy.Direction.Up):
                    boomerang.MovementDirection = Item.Direction.Up;
                    y -= 45;
                    break;
                case (Enemy.Direction.Down):
                    boomerang.MovementDirection = Item.Direction.Down;
                    y += 45;
                    break;
                case (Enemy.Direction.Left):
                    boomerang.MovementDirection = Item.Direction.Left;
                    x -= 45;
                    break;
                case (Enemy.Direction.Right):
                    boomerang.MovementDirection = Item.Direction.Right;
                    x += 45;
                    break;
            }

            boomerangProj = new Projectile(boomerang, gameTime.TotalGameTime.TotalSeconds, x + 18, y + 18);

        }

        public void throwFireBall(GameTime gameTime)
        {
            Item fireBallMid = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.DragonFire, x, y);
            fireBallMid.MovementDirection = Item.Direction.Left;
            fireBallProjMid = new Projectile(fireBallMid, gameTime.TotalGameTime.TotalSeconds, x + 18, y + 18);

            Item fireBallTop = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.DragonFire, x, y);
            fireBallTop.MovementDirection = Item.Direction.UpLeft;
            fireBallProjTop = new Projectile(fireBallTop, gameTime.TotalGameTime.TotalSeconds, x + 18, y + 18);

            Item fireBallBot = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.DragonFire, x, y);
            fireBallBot.MovementDirection = Item.Direction.DownLeft;
            fireBallProjBot = new Projectile(fireBallBot, gameTime.TotalGameTime.TotalSeconds, x + 18, y + 18);

        }
    }
}
