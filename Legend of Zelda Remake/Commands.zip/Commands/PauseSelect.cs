﻿using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework;
using Sprint0;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Media;

namespace Sprint2.Commands
{
    public class PauseSelect : ICommand
    {
        Game1 game;

        public PauseSelect(Game1 g)
        {
            game = g;
        }

        void ICommand.Execute(GameTime gameTime)
        {
            PauseMenu.Select();
            game._soundEffectGenerator.Play("Menu_Select");
            if(PauseMenu.Selection == 0) 
            {
                ICommand Unpause = new TogglePauseCommand(game);
                Unpause.Execute(gameTime);
            }
            else if(PauseMenu.Selection == 1)
            {
                ICommand Unpause = new TogglePauseCommand(game), Reset = new ResetCommand(game);
                Unpause.Execute(gameTime);
                Reset.Execute(gameTime);
            }
            else if(PauseMenu.Selection == 2) 
            {
                if (Game1.CheatsEnabled)
                {
                    Game1.CheatsEnabled = false;
                }
                else 
                {
                    Game1.CheatsEnabled = true;
                }
            }
        }
    }
}
