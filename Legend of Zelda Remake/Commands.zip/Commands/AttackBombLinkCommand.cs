﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;

using Sprint2.Item_Classes;
using Sprint2.Item_Classes.ItemStates;
using Sprint2.Link_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class AttackBombLinkCommand : ICommand
    {
        Game1 game1;
        int x;
        int y;
        LinkStateMachine.Direction direction;
        Projectile bombProj;

        public AttackBombLinkCommand(Game1 game)
        {
            game1 = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            if (LinkInventory.Inventory[Item.ItemCategory.Bomb] != 0)
            {
                game1.link1.ShootProjectile();

                LinkInventory.ThrowBomb();

                x = game1.link1.CurrentXPos + 10;
                y = game1.link1.CurrentYPos;
                direction = game1.link1.direction;

                Item item = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.Bomb, x, y);

                switch (direction)
                {
                    case (LinkStateMachine.Direction.Up):
                        item.MovementDirection = Item.Direction.Up;
                        y -= 45;
                        break;
                    case (LinkStateMachine.Direction.Down):
                        item.MovementDirection = Item.Direction.Down;
                        y += 45;
                        break;
                    case (LinkStateMachine.Direction.Left):
                        item.MovementDirection = Item.Direction.Left;
                        x -= 45;
                        break;
                    case (LinkStateMachine.Direction.Right):
                        item.MovementDirection = Item.Direction.Right;
                        x += 45;
                        break;
                }

                Rectangle dest = new Rectangle(x, y, 24, 42);
                bombProj = new Projectile(item, gameTime.TotalGameTime.TotalSeconds, x, y);
                bombProj.LinkThrow = true;
                game1._soundEffectGenerator.Play("LOZ_Bomb_Drop");
            }

        }
    }
}
