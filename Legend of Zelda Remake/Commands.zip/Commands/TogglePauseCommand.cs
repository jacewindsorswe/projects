﻿using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework;
using Sprint0;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Media;

namespace Sprint2.Commands
{
    public class TogglePauseCommand : ICommand
    {
        Game1 game;

        public TogglePauseCommand(Game1 g)
        {
            game = g;
        }

        void ICommand.Execute(GameTime gameTime)
        {
            if(Game1.GameState == Game1.GameStateType.Normal) 
            {
                if (!MediaPlayer.IsMuted) 
                {
                    MediaPlayer.IsMuted = true;
                }
                Game1.GameState = Game1.GameStateType.Paused;
            }
            else if(Game1.GameState == Game1.GameStateType.Paused) 
            {
                if (!GlobalUtilities.ForceMuted)
                {
                    MediaPlayer.IsMuted = false;
                }
                Game1.GameState = Game1.GameStateType.Normal;
            }
        }
    }
}
