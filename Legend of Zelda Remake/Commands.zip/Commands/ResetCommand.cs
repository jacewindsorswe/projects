﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Media;
using Sprint2;
using Sprint2.Item_Classes;
using Sprint2.Link_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Sprint0
{
    public class ResetCommand : ICommand
    {
        Game1 game;

        public ResetCommand(Game1 g)
        {
            game = g;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            
            game.dungeon.Despawn();
            Game1.GameState = Game1.GameStateType.MainMenu;
            MainMenu.Selected = false;
            MediaPlayer.IsMuted = true;
            MediaPlayer.Play(game.Content.Load<Song>("MainMenuMusicShort"));
            MediaPlayer.IsMuted = false;
            GlobalUtilities.ForceMuted = false;
            Game1.justPlayed = true;

            //game.dungeon.Load(MainMenu.Selection);

            LinkInventory.Heal(60);
            game.link1.CurrentXPos = game.MiddleX;
            game.link1.CurrentYPos = game.MiddleY;

        }
    }
}
