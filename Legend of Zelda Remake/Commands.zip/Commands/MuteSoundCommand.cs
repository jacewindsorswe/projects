﻿using Microsoft.Xna.Framework;
using Sprint2;
using Sprint2.Item_Classes;
using Sprint2.Item_Classes.ItemStates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;

namespace Sprint0
{
    public class MuteSoundCommand : ICommand
    {
        Game1 game;

        public MuteSoundCommand(Game1 g)
        {
            game = g;
        }

        void ICommand.Execute(GameTime gameTime)
        {
            if (!MediaPlayer.IsMuted)
            {
                MediaPlayer.IsMuted = true;
                GlobalUtilities.ForceMuted = true;
            }
            else
            {
                MediaPlayer.IsMuted = false;
                GlobalUtilities.ForceMuted = false;
            }
        }
    }
}