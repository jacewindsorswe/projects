﻿using Microsoft.Xna.Framework;
using Sprint0;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.InventoryCommands
{
    public class SelectCommand : ICommand
    {
        Game1 currentGame;
        public SelectCommand(Game1 game) 
        {
            currentGame = game;
        }
        public void Execute(GameTime gameTime) 
        {
            ItemScreen.Select();
        }
    }
}
