﻿using Microsoft.Xna.Framework;
using Sprint2;
using Sprint2.Item_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class MoveRedBoxLeftCommand : ICommand
    {
        Game1 commandGame;

        public MoveRedBoxLeftCommand(Game1 game)
        {
            commandGame = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            ItemScreen.MoveLeft();
        }
    }
}
