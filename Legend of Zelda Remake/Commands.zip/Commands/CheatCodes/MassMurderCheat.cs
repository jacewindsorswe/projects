﻿using Microsoft.Xna.Framework;
using Sprint2;
using System;
using System.Collections.Generic;
using Sprint2.Enemy_Classes;

namespace Sprint0
{
    public class MassMurderCheat : ICommand
    {
        Game1 game1;
        private static SortedDictionary<int, Enemy> enemiesCopy = new SortedDictionary<int, Enemy>(Enemy.enemies);

        public MassMurderCheat(Game1 game)
        {
            game1 = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            foreach (KeyValuePair<int, Enemy> pair in enemiesCopy)
            {
                Enemy.RemoveEnemy(pair.Key);
            }

        }
    }
}
