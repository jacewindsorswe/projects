﻿using Microsoft.Xna.Framework;
using Sprint2;
using System;
using System.Collections.Generic;
using Sprint2.Link_Classes;

namespace Sprint0
{
    public class GodModeCheat : ICommand
    {
        Game1 game1;

       
        public GodModeCheat(Game1 game)
        {
            game1 = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            if (!game1.link1.GodModeEnabled)
            {
                game1.link1.color = Color.Aquamarine;
                game1.link1.GodModeEnabled = true;
                game1.link1.MakeInvincible(gameTime);
            }
            else
            {
                game1.link1.GodModeEnabled = false;
            }
            

        }
    }
}
