﻿using Microsoft.Xna.Framework;
using Sprint2;
using System;
using System.Collections.Generic;
using Sprint2.Enemy_Classes;
using Microsoft.Xna.Framework.Audio;

namespace Sprint0
{
    public class TimeStopCheat : ICommand
    {
        Game1 game1;
        private static SortedDictionary<int, Enemy> enemiesCopy = new SortedDictionary<int, Enemy>(Enemy.enemies);

        public TimeStopCheat(Game1 game)
        {
            game1 = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            if (!game1.link1.TimeStopped)
            {
                ICommand timeStop = new TimeStop(game1);
                timeStop.Execute(gameTime);
                (game1.Content.Load<SoundEffect>("LOZ_TimeStop")).Play();
                game1.link1.StopTime(gameTime);
                GlobalUtilities.StopTime();
            }
            else 
            {
                GlobalUtilities.ResumeTime(game1.link1, game1, gameTime);
            }
        }
    }
}
