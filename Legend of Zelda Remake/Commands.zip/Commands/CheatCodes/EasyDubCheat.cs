﻿using Microsoft.Xna.Framework;
using Sprint2;
using System;
using System.Collections.Generic;
using Sprint2.Link_Classes;

namespace Sprint0
{
    public class EasyDubCheat : ICommand
    {
        Game1 game1;
        private static SortedDictionary<int, Enemy> enemiesCopy = new SortedDictionary<int, Enemy>(Enemy.enemies);
        private static int numKeys = LinkInventory.keys;
        private static int numBombs = LinkInventory.bombs;
        private static int health = LinkInventory.health;

        public EasyDubCheat(Game1 game)
        {
            game1 = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {

            if (!game1.link1.EasyDubModeEnabled)
            {
                game1.link1.EasyDubModeEnabled = true;
                foreach (KeyValuePair<int, Enemy> pair in enemiesCopy)
                {
                    pair.Value.EasyDubMode = true;
                }

                game1.link1.color = Color.Chocolate;
                game1.link1.GodModeEnabled = true;
                game1.link1.MakeInvincible(gameTime);

                LinkInventory.FullHealth();
                LinkInventory.MaxBombs();
                LinkInventory.MaxKeys();
            }
            else
            {
                game1.link1.EasyDubModeEnabled = false;
                foreach (KeyValuePair<int, Enemy> pair in enemiesCopy)
                {
                    pair.Value.EasyDubMode = false;
                }

                game1.link1.color = Color.White;
                game1.link1.GodModeEnabled = false;

                LinkInventory.keys = numKeys;
                LinkInventory.bombs = numBombs;
                LinkInventory.health = health;

            }

        }
    }
}
