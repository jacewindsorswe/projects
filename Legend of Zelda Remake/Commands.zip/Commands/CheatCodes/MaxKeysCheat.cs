﻿using Microsoft.Xna.Framework;
using Sprint2;
using System;
using System.Collections.Generic;
using Sprint2.Link_Classes;

namespace Sprint0
{
    public class MaxKeysCheat : ICommand
    {
        Game1 game1;


        public MaxKeysCheat(Game1 game)
        {
            game1 = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {

            LinkInventory.MaxKeys();

        }
    }
}
