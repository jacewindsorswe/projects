﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Enemy_Classes;
using Sprint2.Interfaces;
using Sprint2.Item_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.EnemyEnemyCollisions
{
    public class ResolveEnemyItemEqualCollision : ICollisionCommand
    {
        private Game1 commandGame;
        public ResolveEnemyItemEqualCollision(Game1 game)
        {
            commandGame = game;
        }

        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            Rectangle Intersection = Microsoft.Xna.Framework.Rectangle.Intersect(c1.CurrentHitbox, c2.CurrentHitbox);
            Item.Direction pDirect = ((Item)c2).MovementDirection;

            if (((Item)c2).ItemClass == Item.ItemCategory.Sword)
            {
                switch (pDirect)
                {
                    case Item.Direction.Left:
                        ((Enemy)c1).Right(Intersection.Width);
                        break;
                    case Item.Direction.Right:
                        ((Enemy)c1).Left(Intersection.Width);
                        break;
                    case Item.Direction.Up:
                        ((Enemy)c1).Down(Intersection.Height);
                        break;
                    default:
                        ((Enemy)c1).Up(Intersection.Height);
                        break;
                }

                ((Enemy)c1).TakeDamage(((Item)c2).Damage);
                if (!(((Enemy)c1).Alive))
                {
                    commandGame.deathAnimations.Add(new DeathAnimation(DeathAnimation.DeathType.Enemy, ((Enemy)c1).CurrentHitbox, gameTime.TotalGameTime.TotalSeconds));
                }
            }
        }
    }
}
