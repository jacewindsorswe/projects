﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Enemy_Classes;
using Sprint2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.EnemyEnemyCollisions
{
    public class ResolveLinkProjectileTopCollision : ICollisionCommand
    {
        private Game1 commandGame;
        public ResolveLinkProjectileTopCollision(Game1 game)
        {
            commandGame = game;
        }

        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            if (!((Projectile)c2).LinkThrow && ((Projectile)c2).ItemClass != Item_Classes.Item.ItemCategory.OrangeParticle)
            {
                Rectangle Intersection = Microsoft.Xna.Framework.Rectangle.Intersect(c1.CurrentHitbox, c2.CurrentHitbox);
                ((Link)c1).Down(Intersection.Height);
                ((Link)c1).direction = LinkStateMachine.Direction.Down;
                ((Link)c1).TakeDamage(gameTime, ((Projectile)c2).Damage);
                commandGame.deathAnimations.Add(new DeathAnimation(GlobalUtilities.convertItemtoDeathType(((Projectile)c2).ItemClass), new Rectangle(((Projectile)c2).X, ((Projectile)c2).Y, GlobalUtilities.PROJECTILE_DEATH_ANIMATION_SIZE, GlobalUtilities.PROJECTILE_DEATH_ANIMATION_SIZE), gameTime.TotalGameTime.TotalSeconds));
                ((Projectile)c2).Exists = false;
            }
        }
    }
}
