﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.LinkEnemyCollisions
{
    public class ResolveLinkEnemyLeftCollision : ICollisionCommand
    {
        private Game1 currentGame;
        public ResolveLinkEnemyLeftCollision(Game1 game)
        {
            currentGame = game;
        }

        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            if (!((Link)c1).IsInvincible)
            {
                Rectangle Intersection = Microsoft.Xna.Framework.Rectangle.Intersect(c1.CurrentHitbox, c2.CurrentHitbox);
                ((Link)c1).Right(Intersection.Width);
                ((Link)c1).direction = LinkStateMachine.Direction.Right;
                ((Link)c1).TakeDamage(gameTime, ((Enemy)c2).EnemyDamage);
            }
        }
    }
}
