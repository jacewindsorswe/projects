﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.LinkEnemyCollisions
{
    public class ResolveLinkEnemyEqualCollision : ICollisionCommand
    {
        private Game1 commandGame;
        public ResolveLinkEnemyEqualCollision(Game1 game)
        {
            commandGame = game;
        }

        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            if (!((Link)c1).IsInvincible)
            {
                Rectangle Intersection = Microsoft.Xna.Framework.Rectangle.Intersect(c1.CurrentHitbox, c2.CurrentHitbox);
                CollisionUtilities.CornerType corner = CollisionUtilities.WhichCorner(c1.CurrentHitbox, c2.CurrentHitbox);
                switch (corner)
                {
                    case CollisionUtilities.CornerType.TopLeft:
                        ((Link)c1).Down(Intersection.Height);
                        ((Link)c1).direction = LinkStateMachine.Direction.Down;
                        ((Link)c1).TakeDamage(gameTime, ((Enemy)c2).EnemyDamage);
                        break;
                    case CollisionUtilities.CornerType.TopRight:
                        ((Link)c1).Down(Intersection.Height);
                        ((Link)c1).direction = LinkStateMachine.Direction.Down;
                        ((Link)c1).TakeDamage(gameTime, ((Enemy)c2).EnemyDamage);
                        break;
                    case CollisionUtilities.CornerType.BottomLeft:
                        ((Link)c1).Up(Intersection.Height);
                        ((Link)c1).direction = LinkStateMachine.Direction.Up;
                        ((Link)c1).TakeDamage(gameTime, ((Enemy)c2).EnemyDamage);
                        break;
                    case CollisionUtilities.CornerType.BottomRight:
                        ((Link)c1).Up(Intersection.Height);
                        ((Link)c1).direction = LinkStateMachine.Direction.Up;
                        ((Link)c1).TakeDamage(gameTime, ((Enemy)c2).EnemyDamage);
                        break;
                }
            }
        }
    }
}
