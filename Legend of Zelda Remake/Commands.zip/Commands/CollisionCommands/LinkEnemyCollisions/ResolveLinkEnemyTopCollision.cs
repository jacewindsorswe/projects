﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.LinkEnemyCollisions
{
    public class ResolveLinkEnemyTopCollision : ICollisionCommand
    {
        private Game1 currentGame;
        public ResolveLinkEnemyTopCollision(Game1 game)
        {
            currentGame = game;
        }

        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            if (!((Link)c1).IsInvincible)
            {
                Rectangle Intersection = Microsoft.Xna.Framework.Rectangle.Intersect(c1.CurrentHitbox, c2.CurrentHitbox);
                ((Link)c1).Down(Intersection.Height);
                ((Link)c1).direction = LinkStateMachine.Direction.Down;
                ((Link)c1).TakeDamage(gameTime, ((Enemy)c2).EnemyDamage);
            }
        }
    }
}
