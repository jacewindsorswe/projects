﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Enemy_Classes;
using Sprint2.Interfaces;
using Sprint2.Item_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.EnemyEnemyCollisions
{
    public class ResolveEnemyProjectileEqualCollision : ICollisionCommand
    {
        private Game1 commandGame;
        public ResolveEnemyProjectileEqualCollision(Game1 game)
        {
            commandGame = game;
        }

        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            if (((Projectile)c2).LinkThrow && ((Projectile)c2).ItemClass != Item.ItemCategory.OrangeParticle && ((Projectile)c2).ItemClass != Item.ItemCategory.Bomb)
            {
                Rectangle Intersection = Microsoft.Xna.Framework.Rectangle.Intersect(c1.CurrentHitbox, c2.CurrentHitbox);
                Item.Direction pDirect = ((Projectile)c2).MovementDirection;
                switch (pDirect)
                {
                    case Item.Direction.Left:
                        ((Enemy)c1).Left(Intersection.Width);
                        break;
                    case Item.Direction.Right:
                        ((Enemy)c1).Right(Intersection.Width);
                        break;
                    case Item.Direction.Up:
                        ((Enemy)c1).Up(Intersection.Height);
                        break;
                    default:
                        ((Enemy)c1).Down(Intersection.Height);
                        break;
                }

                ((Enemy)c1).TakeDamage(((Projectile)c2).Damage);
                if (((Enemy)c1).CurrentEnemyType == Enemy.EnemyType.Dodongo && ((Projectile)c2).ItemClass == Item.ItemCategory.ExplosiveCloud)
                {
                    ((Enemy)c1).Stunned = true;
                    ((Enemy)c1).StunTime = gameTime.TotalGameTime.TotalSeconds;
                }

                if (!(((Enemy)c1).Alive))
                {
                    commandGame.deathAnimations.Add(new DeathAnimation(DeathAnimation.DeathType.Enemy, ((Enemy)c1).CurrentHitbox, gameTime.TotalGameTime.TotalSeconds));
                }
                ((Projectile)c2).Exists = false;

                Projectile proj = ((Projectile)c2);
                if (commandGame.explodablesP.Contains(proj.ItemClass))
                {
                    if (proj.ItemClass != Item.ItemCategory.Bomb)
                    {
                        Explosion expl = new Explosion(Item.ItemCategory.OrangeParticle, proj.CurrentHitbox.X + proj.CurrentHitbox.Width, proj.CurrentHitbox.Y + proj.CurrentHitbox.Height, proj.CurrentHitbox.X, proj.CurrentHitbox.Y, gameTime);
                        foreach (Projectile part in expl.ParticleList)
                        {
                            if (proj.LinkThrow == true)
                            {
                                part.LinkThrow = true;
                            }
                        }
                    }
                    else
                    {
                        Explosion expl = new Explosion(Item.ItemCategory.ExplosiveCloud, proj.CurrentHitbox.X + proj.CurrentHitbox.Width, proj.CurrentHitbox.Y + proj.CurrentHitbox.Height, proj.CurrentHitbox.X, proj.CurrentHitbox.Y, gameTime);
                        foreach (Projectile part in expl.ParticleList)
                        {
                            if (proj.LinkThrow == true)
                            {
                                part.LinkThrow = true;
                            }
                        }
                    }
                }
            }
            if (((Projectile)c2).ItemClass == Item.ItemCategory.Bomb && ((Enemy)c1).CurrentEnemyType == Enemy.EnemyType.Dodongo)
            {
                if (((Dodongo)c1).CurrentDirection == Enemy.Direction.Down)
                {
                    ((Projectile)c2).Pickup();
                    ((Dodongo)c1).ExplodeInside(gameTime);
                }
            }
        }
    }
}
