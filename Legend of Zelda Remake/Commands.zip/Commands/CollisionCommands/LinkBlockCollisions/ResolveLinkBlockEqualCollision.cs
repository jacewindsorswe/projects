﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Block_Classes;
using Sprint2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.EnemyEnemyCollisions
{
    public class ResolveLinkBlockEqualCollision : ICollisionCommand
    {
        private Game1 commandGame;
        public ResolveLinkBlockEqualCollision(Game1 game)
        {
            commandGame = game;
        }

        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            Rectangle Intersection = Microsoft.Xna.Framework.Rectangle.Intersect(c1.CurrentHitbox, c2.CurrentHitbox);
            CollisionUtilities.CornerType corner = CollisionUtilities.WhichCorner(c1.CurrentHitbox, c2.CurrentHitbox);

            if(((Link)c1).CurrentAction != LinkStateMachine.ActionType.Knockback) 
            {
                switch (Link.GetOppositeDirection(((Link)c1).direction)) 
                {
                    case LinkStateMachine.Direction.Up:
                        ((Link)c1).Up(Intersection.Height + GlobalUtilities.LINK_COLLISION_OFFSET);
                        break;
                    case LinkStateMachine.Direction.Down:
                        ((Link)c1).Down(Intersection.Height + GlobalUtilities.LINK_COLLISION_OFFSET);
                        break;
                    case LinkStateMachine.Direction.Right:
                        ((Link)c1).Right(Intersection.Width + GlobalUtilities.LINK_COLLISION_OFFSET);
                        break;
                    default:
                        ((Link)c1).Left(Intersection.Width + GlobalUtilities.LINK_COLLISION_OFFSET);
                        break;
                }
            }
            else 
            {
                switch (corner)
                {
                    case CollisionUtilities.CornerType.TopLeft:
                        ((Link)c1).Down(Intersection.Height + GlobalUtilities.LINK_COLLISION_OFFSET);
                        break;
                    case CollisionUtilities.CornerType.TopRight:
                        ((Link)c1).Down(Intersection.Height + GlobalUtilities.LINK_COLLISION_OFFSET);
                        break;
                    case CollisionUtilities.CornerType.BottomLeft:
                        ((Link)c1).Up(Intersection.Height + GlobalUtilities.LINK_COLLISION_OFFSET);
                        break;
                    case CollisionUtilities.CornerType.BottomRight:
                        ((Link)c1).Up(Intersection.Height + GlobalUtilities.LINK_COLLISION_OFFSET);
                        break;
                }
            }

            if (((BlockStateMachine)c2).Type == BlockStateMachine.BlockType.HorizontalLockedDoor || ((BlockStateMachine)c2).Type == BlockStateMachine.BlockType.VerticalLockedDoor)
            {
                if (((Link)c1).NumKeys > 0)
                {
                    ((Link)c1).UnlockDoor();
                    ((BlockStateMachine)c2).Unlock();

                    Rectangle doorHitbox = ((BlockStateMachine)c2).CurrentHitbox;
                    LinkStateMachine.Direction doorDirection = Dungeon.CoordinatesToDirection(doorHitbox.X, doorHitbox.Y, doorHitbox.Height, doorHitbox.Width);

                    GlobalUtilities.ToggleOppositeDoor(doorDirection, commandGame.dungeon.RoomPosX, commandGame.dungeon.RoomPosY, commandGame.dungeon);
                }
            }
            if (((BlockStateMachine)c2).CanTeleport)
            {

            }
        }
    }
}
