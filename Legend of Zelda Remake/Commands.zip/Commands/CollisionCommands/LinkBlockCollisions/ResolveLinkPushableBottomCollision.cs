﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Block_Classes;
using Sprint2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.EnemyEnemyCollisions
{
    public class ResolveLinkPushableBottomCollision : ICollisionCommand
    {
        private Game1 commandGame;
        public ResolveLinkPushableBottomCollision(Game1 game)
        {
            commandGame = game;
        }

        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            Rectangle Intersection = Microsoft.Xna.Framework.Rectangle.Intersect(c1.CurrentHitbox, c2.CurrentHitbox);
            BlockStateMachine block = (BlockStateMachine)c2;
            Link link = (Link)c1;

            //block.Move(Intersection.Height + CollisionUtilities.MovementSpeed(link), LinkStateMachine.Direction.Down);
            if (!block.Moving)
            {
                block.Push(LinkStateMachine.Direction.Down);
            }
            link.Up(Intersection.Height);
        }
    }
}
