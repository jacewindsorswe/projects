﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Block_Classes;
using Sprint2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.LinkBlockCollisions
{
    public class ResolvePushableBlockRightCollision : ICollisionCommand
    {
        private Game1 commandGame;
        public ResolvePushableBlockRightCollision(Game1 game)
        {
            commandGame = game;
        }

        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            Rectangle Intersection = Microsoft.Xna.Framework.Rectangle.Intersect(c1.CurrentHitbox, c2.CurrentHitbox);
            ((BlockStateMachine)c1).Move(Intersection.Width, LinkStateMachine.Direction.Left);
            ((BlockStateMachine)c1).Moving = false;
        }
    }
}
