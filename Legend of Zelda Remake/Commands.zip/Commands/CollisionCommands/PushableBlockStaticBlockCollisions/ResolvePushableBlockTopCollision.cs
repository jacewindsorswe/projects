﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Block_Classes;
using Sprint2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.EnemyEnemyCollisions
{
    public class ResolvePushableBlockTopCollision : ICollisionCommand
    {
        private Game1 commandGame;
        public ResolvePushableBlockTopCollision(Game1 game)
        {
            commandGame = game;
        }

        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            Rectangle Intersection = Microsoft.Xna.Framework.Rectangle.Intersect(c1.CurrentHitbox, c2.CurrentHitbox);
            ((BlockStateMachine)c1).Move(Intersection.Height, LinkStateMachine.Direction.Down);
            ((BlockStateMachine)c1).Moving = false;
        }
    }
}
