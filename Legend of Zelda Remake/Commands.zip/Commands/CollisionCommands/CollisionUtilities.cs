﻿using Microsoft.Xna.Framework;
using Sprint0;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands
{
    public static class CollisionUtilities
    {
        //Gets passed two hitboxes, compares them, and returns the corner they collided on
        public enum CornerType 
        {
            TopLeft,
            TopRight,
            BottomLeft,
            BottomRight
        }
        
        public static CornerType WhichCorner(Rectangle a, Rectangle b) 
        {
            int xDiff = a.X - b.X;
            int yDiff = a.Y - b.Y;

            if(xDiff >= 0 && yDiff >= 0) 
            {
                return CornerType.TopLeft;
            }
            else if(xDiff >= 0) 
            {
                return CornerType.BottomLeft;
            }
            else if(yDiff >= 0) 
            {
                return CornerType.TopRight;
            }
            else 
            {
                return CornerType.BottomRight;
            }
        }

        public static int MovementSpeed(Link l) 
        {
            if(l.CurrentAction == LinkStateMachine.ActionType.Moving) 
            {
                return GlobalUtilities.LINK_SPEED;
            }
            else 
            {
                return 0;
            }
        }
    }
}
