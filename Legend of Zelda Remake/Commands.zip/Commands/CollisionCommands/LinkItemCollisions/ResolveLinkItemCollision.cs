﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;
using Sprint0;
using Sprint2.Interfaces;
using Sprint2.Item_Classes;
using Sprint2.Link_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.LinkItemCollisions
{
    public class ResolveLinkItemCollision : ICollisionCommand
    {
        Game1 currentGame;
        SoundEffect soundEffect;
        private Dictionary<Item.ItemCategory, string> soundEffects = new()
        {
            { Item.ItemCategory.Rupee, "LOZ_Get_Rupee" },
            { Item.ItemCategory.BigHeart, "LOZ_Get_Heart" },
            { Item.ItemCategory.Clock, "LOZ_TimeStop" },
        };
        public ResolveLinkItemCollision(Game1 game) 
        {
            currentGame = game;
        }
        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            if (((Item)c2).ItemClass == Item.ItemCategory.Rupee)
            {
                ((Link)c1).CollectRupee(RandomNumberGenerator.GetInt32(1, 10));
            }
            if (((Item)c2).ItemClass == Item.ItemCategory.Key)
            {
                ((Link)c1).CollectKey();
            }
            if (((Item)c2).ItemClass == Item.ItemCategory.Bomb)
            {
                LinkInventory.PickupBomb();
            }
            if (((Item)c2).ItemClass == Item.ItemCategory.BigHeart) 
            {
                LinkInventory.MaxHealth += 40;
                LinkInventory.Heal(30);
            }
            if(((Item)c2).ItemClass == Item.ItemCategory.Clock) 
            {
                ICommand timeStop = new TimeStop(currentGame);
                timeStop.Execute(gameTime);
                ((Link)c1).StopTime(gameTime);
                GlobalUtilities.StopTime();
            }
            if (((Item)c2).ItemClass == Item.ItemCategory.SmallHeart)
            {
                LinkInventory.Heal(20);
            }
            if (((Item)c2).ItemClass == Item.ItemCategory.GoldenTicket)
            {
                LinkInventory.PickupMap();
            }
            if (((Item)c2).ItemClass == Item.ItemCategory.Bow)
            {
                LinkInventory.PickupBow();
            }
            if (((Item)c2).ItemClass == Item.ItemCategory.Compass)
            {
                LinkInventory.PickupCompass();
            }
            if (((Item)c2).ItemClass == Item.ItemCategory.OrangeTriangle)
            {
                //System.Diagnostics.Debug.WriteLine("OrangeTriangle");
                LinkInventory.Inventory[Item.ItemCategory.GoldenTicket] = 1;
                Game1.GameState = Game1.GameStateType.GameWin;
                Game1.winTime = gameTime.TotalGameTime.TotalSeconds;
                ((Link)c1).Win = true;
                MediaPlayer.IsMuted = true;
                currentGame._soundEffectGenerator.Play("LOZ_TriforceObtained");

                foreach(Item item in Item.ItemList) 
                {
                    if (item.IsActive) 
                    {
                        item.X = ((Link)c1).CurrentXPos + ((((Link)c1).CurrentHitbox.Width / 2) - (item.Width / 2));
                        item.Y = ((Link)c1).CurrentYPos - item.Height;
                    }
                }
            }
            if (((Item)c2).ItemClass != Item.ItemCategory.Sword && ((Item)c2).ItemClass != Item.ItemCategory.Fire && ((Item)c2).ItemClass != Item.ItemCategory.OrangeTriangle)
            {
                //System.Diagnostics.Debug.WriteLine(((ItemStateMachine)c2).ItemClass);
                ((Item)c2).Pickup();
            }
            if (soundEffects.ContainsKey(((Item)c2).ItemClass))
            {
                soundEffect = currentGame.Content.Load<SoundEffect>(soundEffects[((Item)c2).ItemClass]);
            }
            else 
            {
                if (((Item)c2).ItemClass != Item.ItemCategory.Sword)
                {
                    soundEffect = currentGame.Content.Load<SoundEffect>("LOZ_Get_Item");
                }
            }
            if (((Item)c2).ItemClass != Item.ItemCategory.Sword)
            {
                soundEffect.Play();
            }
        }
    }
}
