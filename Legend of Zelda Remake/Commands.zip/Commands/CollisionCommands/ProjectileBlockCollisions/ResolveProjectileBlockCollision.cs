﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Block_Classes;
using Sprint2.Enemy_Classes;
using Sprint2.Interfaces;
using Sprint2.Item_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.LinkItemCollisions
{
    public class ResolveProjectileBlockCollision : ICollisionCommand
    {
        Game1 currentGame;
        public ResolveProjectileBlockCollision(Game1 game) 
        {
            currentGame = game;
        }
        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            if (!((BlockStateMachine)c2).IsGap && ((Projectile)c1).ItemClass != Item.ItemCategory.OrangeParticle && ((Projectile)c1).ItemClass != Item.ItemCategory.ExplosiveCloud && ((Projectile)c1).ItemClass != Item.ItemCategory.Bomb)
            {
                currentGame.deathAnimations.Add(new DeathAnimation(DeathAnimation.DeathType.Projectile, new Rectangle(((Projectile)c1).X, ((Projectile)c1).Y, GlobalUtilities.PROJECTILE_DEATH_ANIMATION_SIZE, GlobalUtilities.PROJECTILE_DEATH_ANIMATION_SIZE), gameTime.TotalGameTime.TotalSeconds));
                ((Projectile)c1).Pickup();


                if (currentGame.explodablesP.Contains(((Projectile)c1).ItemClass))
                {
                    if (((Projectile)c1).ItemClass != Item.ItemCategory.Bomb)
                    {
                        Explosion expl = new Explosion(Item.ItemCategory.OrangeParticle, ((Projectile)c1).CurrentHitbox.X + ((Projectile)c1).CurrentHitbox.Width, ((Projectile)c1).CurrentHitbox.Y + ((Projectile)c1).CurrentHitbox.Height, ((Projectile)c1).CurrentHitbox.X, ((Projectile)c1).CurrentHitbox.Y, gameTime);
                        foreach (Projectile part in expl.ParticleList)
                        {
                            if (((Projectile)c1).LinkThrow == true)
                            {
                                part.LinkThrow = true;
                            }
                        }
                    }
                    else
                    {
                        Explosion expl = new Explosion(Item.ItemCategory.ExplosiveCloud, ((Projectile)c1).CurrentHitbox.X + ((Projectile)c1).CurrentHitbox.Width, ((Projectile)c1).CurrentHitbox.Y + ((Projectile)c1).CurrentHitbox.Height, ((Projectile)c1).CurrentHitbox.X, ((Projectile)c1).CurrentHitbox.Y, gameTime);
                        foreach (Projectile part in expl.ParticleList)
                        {
                            if (((Projectile)c1).LinkThrow == true)
                            {
                                part.LinkThrow = true;
                            }
                        }
                    }
                }
            }
            if(((BlockStateMachine)c2).Type == BlockStateMachine.BlockType.ExplodableDoor && ((Projectile)c1).ItemClass == Item.ItemCategory.ExplosiveCloud) 
            {
                ((BlockStateMachine)c2).Unlock();

                Rectangle doorHitbox = ((BlockStateMachine)c2).CurrentHitbox;
                LinkStateMachine.Direction doorDirection = Dungeon.CoordinatesToDirection(doorHitbox.X, doorHitbox.Y, doorHitbox.Height, doorHitbox.Width);

                GlobalUtilities.ToggleOppositeDoor(doorDirection, currentGame.dungeon.RoomPosX, currentGame.dungeon.RoomPosY, currentGame.dungeon);
            }
        }
    }
}
