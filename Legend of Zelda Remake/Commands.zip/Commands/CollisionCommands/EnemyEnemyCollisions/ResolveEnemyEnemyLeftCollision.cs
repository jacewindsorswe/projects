﻿using Microsoft.VisualBasic;
using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.EnemyEnemyCollisions
{
    public class ResolveEnemyEnemyLeftCollision : ICollisionCommand
    {
        private Game1 commandGame;
        public ResolveEnemyEnemyLeftCollision(Game1 game)
        {
            commandGame = game;
        }

        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            Rectangle Intersection = Microsoft.Xna.Framework.Rectangle.Intersect(c1.CurrentHitbox, c2.CurrentHitbox);
            ((Enemy)c1).Right(Intersection.Width + GlobalUtilities.ENEMY_COLLISION_OFFSET);
            ((Enemy)c2).Left(Intersection.Width + GlobalUtilities.ENEMY_COLLISION_OFFSET);

            if (((Enemy)c1).CurrentEnemyType != Enemy.EnemyType.Blade)
            {
                ((Enemy)c1).CurrentDirection = GlobalUtilities.RandomDirection(((Enemy)c1).CurrentDirection);
                ((Enemy)c2).CurrentDirection = GlobalUtilities.RandomDirection(((Enemy)c2).CurrentDirection);
            }
            else
            {
                ((Enemy)c1).CurrentDirection = GlobalUtilities.GetDirectionOpposite(((Enemy)c1).CurrentDirection);
                ((Enemy)c2).CurrentDirection = GlobalUtilities.GetDirectionOpposite(((Enemy)c2).CurrentDirection);
            }
        }
    }
}
