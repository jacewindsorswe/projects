﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Block_Classes;
using Sprint2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.CollisionCommands.EnemyBlockCollisions
{
    public class ResolveEnemyBlockTopCollision : ICollisionCommand
    {
        private Game1 commandGame;
        public ResolveEnemyBlockTopCollision(Game1 game)
        {
            commandGame = game;
        }

        public void Execute(GameTime gameTime, CollidableObject c1, CollidableObject c2)
        {
            if ((((Enemy)c1).CurrentEnemyType == Enemy.EnemyType.Keese && ((BlockStateMachine)c2).IsWall) || (((Enemy)c1).CurrentEnemyType != Enemy.EnemyType.Wallmaster && ((Enemy)c1).CurrentEnemyType != Enemy.EnemyType.Keese))
            {
                Rectangle Intersection = Microsoft.Xna.Framework.Rectangle.Intersect(c1.CurrentHitbox, c2.CurrentHitbox);
                ((Enemy)c1).Down(Intersection.Height + GlobalUtilities.ENEMY_COLLISION_OFFSET);

                if(((Enemy)c1).CurrentEnemyType == Enemy.EnemyType.Blade) 
                {
                    ((Blade)c1).State = Blade.BladeState.Sensing;
                }
                else
                {
                    ((Enemy)c1).CurrentDirection = GlobalUtilities.RandomDirection(((Enemy)c1).CurrentDirection);
                }
            }
        }
    }
}
