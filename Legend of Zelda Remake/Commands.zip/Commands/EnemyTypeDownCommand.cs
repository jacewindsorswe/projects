﻿  using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Sprint0
{
    public class EnemyTypeDownCommand : ICommand
    {
        Game1 game;
        public EnemyTypeDownCommand(Game1 g)
        {
            game = g;
        }

        void ICommand.Execute(GameTime gameTime)
        {
            Enemy enemy;
            enemy = (Enemy)game.enemy;
            int currentEnemy = (int)enemy.CurrentEnemyType;
            if(currentEnemy == 0)
            {
                currentEnemy = 4;
            }
            else
            {
                currentEnemy -= 1;
            }
            switch(currentEnemy){
                case 0:
                    game.enemy = new Stalfos(game);
                    break;
                case 1:
                    game.enemy = new Darknut(game);
                    break;
                case 2:
                    game.enemy = new Wizzrobe(game);
                    break;
                case 3:
                    game.enemy = new Goriya(game);
                    break;
                case 4:
                    game.enemy = new Aquamentus(game);
                    break;
            }

        }


    }



}