﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Sprint2.Item_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class AttackBlueBoomerangLinkCommand : ICommand
    {
        Game1 game1;
        int x;
        int y;
        LinkStateMachine.Direction direction;
        Projectile boomerangProj;

        public AttackBlueBoomerangLinkCommand(Game1 game)
        {
            game1 = game;
        }

        void ICommand.Execute(GameTime gameTime)
        {
            game1.link1.ShootProjectile();

            x = game1.link1.CurrentXPos;
            y = game1.link1.CurrentYPos;
            direction = game1.link1.direction;

            Item boomerang = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.BlueBoomerang, x, y);

            switch (direction)
            {
                case (LinkStateMachine.Direction.Up):
                    boomerang.MovementDirection = Item.Direction.Up;
                    y -= 45;
                    break;
                case (LinkStateMachine.Direction.Down):
                    boomerang.MovementDirection = Item.Direction.Down;
                    y += 45;
                    break;
                case (LinkStateMachine.Direction.Left):
                    boomerang.MovementDirection = Item.Direction.Left;
                    x -= 45;
                    break;
                case (LinkStateMachine.Direction.Right):
                    boomerang.MovementDirection = Item.Direction.Right;
                    x += 45;
                    break;
            }

            boomerangProj = new Projectile(boomerang, gameTime.TotalGameTime.TotalSeconds, x + 18, y + 18);

            boomerangProj.LinkThrow = true;
            game1._soundEffectGenerator.Play("LOZ_Arrow_Boomerang");

        }
    }
}
