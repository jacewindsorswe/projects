﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class ChangeRoomUpCommand : ICommand
    {
        Game1 commandGame;
        public ChangeRoomUpCommand(Game1 game)
        {
            commandGame = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            if (Game1.GameState != Game1.GameStateType.MainMenu)
            {
                commandGame.dungeon.ChangeRoomUp();
            }
        }
    }
}
