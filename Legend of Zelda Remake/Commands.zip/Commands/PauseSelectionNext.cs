﻿using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework;
using Sprint0;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Media;

namespace Sprint2.Commands
{
    public class PauseSelectionNext : ICommand
    {
        Game1 game;

        public PauseSelectionNext(Game1 g)
        {
            game = g;
        }

        void ICommand.Execute(GameTime gameTime)
        {
            PauseMenu.MoveNext();
        }
    }
}
