﻿using Microsoft.Xna.Framework;
using Sprint2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class MoveLinkLeftCommand : ICommand
    {
        Game1 commandGame;
            public MoveLinkLeftCommand(Game1 game)
        {
            commandGame = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            if (!GlobalUtilities.DisableHorizontal)
            {
                commandGame.link1.Left();
            }
        }
    }
}
