﻿using Microsoft.Xna.Framework;
using Sprint0;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands.InventoryCommands
{
    public class MenuSelectCommand : ICommand
    {
        Game1 currentGame;
        public MenuSelectCommand(Game1 game) 
        {
            currentGame = game;
        }
        public void Execute(GameTime gameTime) 
        {
            MainMenu.Select(gameTime);
            currentGame._soundEffectGenerator.Play("Menu_Select");
            currentGame.dungeon.Load(MainMenu.Selection);
        }
    }
}
