﻿using Microsoft.Xna.Framework;
using Sprint2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class MoveLinkUpCommand : ICommand
    {
        Game1 commandGame;
            public MoveLinkUpCommand(Game1 game)
        {
            commandGame = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            if (!GlobalUtilities.DisableVertical)
            {
                commandGame.link1.Up();
            }
        }
    }
}
