﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Sprint2.Item_Classes;
using Sprint2.Item_Classes.ItemStates;
using Sprint2.Link_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class AttackSwordLinkCommand : ICommand
    {
        Game1 commandGame;
        private int x;
        private int y;
        private int width;
        private int height;
        LinkStateMachine.Direction direction;
        Item sword;

        Projectile swordProj;

        public AttackSwordLinkCommand(Game1 game)
        {
            commandGame = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            //gotta fix the magic numbers in here
            commandGame.link1.AttackSword();
            if (LinkInventory.Health == LinkInventory.MaxHealth)
            {
                x = commandGame.link1.CurrentXPos;
                y = commandGame.link1.CurrentYPos;

                
                direction = commandGame.link1.direction;

                switch (direction)
                {
                    case (LinkStateMachine.Direction.Up):
                        sword = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.UpSwordProj, x, y);
                        sword.MovementDirection = Item.Direction.Up;
                        sword.Y -= 32;
                        sword.X += 6;
                        break;
                    case (LinkStateMachine.Direction.Down):
                        sword = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.DownSwordProj, x, y);
                        sword.MovementDirection = Item.Direction.Down;
                        sword.Y += 45;
                        sword.X += 22;
                        break;
                    case (LinkStateMachine.Direction.Left):
                        sword = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.LeftSwordProj, x, y);
                        sword.MovementDirection = Item.Direction.Left;
                        sword.X -= 32;
                        sword.Y += 21;
                        break;
                    case (LinkStateMachine.Direction.Right):
                        sword = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.RightSwordProj, x, y);
                        sword.MovementDirection = Item.Direction.Right;
                        sword.X += 45;
                        sword.Y += 21;
                        break;
                }

                commandGame._soundEffectGenerator.Play("LOZ_Sword_Combined");

                swordProj = new Projectile(sword, gameTime.TotalGameTime.TotalSeconds, sword.X, sword.Y);
                swordProj.LinkThrow = true;
            } else
            {
                commandGame._soundEffectGenerator.Play("LOZ_Sword_Slash");
            }
        }
    }
}