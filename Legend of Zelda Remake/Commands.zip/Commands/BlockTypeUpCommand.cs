﻿using Microsoft.Xna.Framework;
using Sprint2.Block_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class BlockTypeUpCommand : ICommand
    {
        Game1 commandGame;
            public BlockTypeUpCommand(Game1 game)
        {
            commandGame = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            BlockStateMachine block;
            block = commandGame.BlockSprite;
            int current = (int) block.Kind;
            if (current == 8)
            {
                current = 0;
            }
            else
            {
                //Used to override transition from fire sprite to non fire sprite (so that pressing the button to switch sprites doesn't go fire_frame_1 --> fire_frame_2
                //but rather fire_frame_X --> non_fire_frame)
                current += 1;
            }
            commandGame.BlockSprite.Exists = false;
            commandGame.BlockSprite = BlockSpriteFactory.Instance.CreateBlock(block.X, block.Y, block.Type, (BlockSpriteFactory.BlockKind)current);
        }
    }
}
