﻿using Microsoft.Xna.Framework;
using Sprint2.Item_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class ItemTypeDownCommand : ICommand
    {
        Game1 game;
        public ItemTypeDownCommand(Game1 g)
        {
            game = g;
        }

        void ICommand.Execute(GameTime gameTime)
        {
            Item item;
            item = game.ItemSprite;

            switch (item.ItemClass)
            {
                case Item.ItemCategory.Bow:
                    item.ItemClass = Item.ItemCategory.Rupee;
                    break;
                case Item.ItemCategory.Rupee:
                    item.ItemClass = Item.ItemCategory.Fire;
                    break;
                case Item.ItemCategory.Fire:
                    item.ItemClass = Item.ItemCategory.Key;
                    break;
                case Item.ItemCategory.Key:
                    item.ItemClass = Item.ItemCategory.BigHeart;
                    break;
                case Item.ItemCategory.BigHeart:
                    item.ItemClass = Item.ItemCategory.Clock;
                    break;
                case Item.ItemCategory.Clock:
                    item.ItemClass = Item.ItemCategory.SmallHeart;
                    break;
                default:
                    item.ItemClass = Item.ItemCategory.Bow;
                    break;
            }
            item.Exists = false;
            game.ItemSprite = ItemSpriteFactory.Instance.CreateItem(item.ItemClass, item.X, item.Y);
        }


    }


}
