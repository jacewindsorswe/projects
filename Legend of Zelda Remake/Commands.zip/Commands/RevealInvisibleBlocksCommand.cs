﻿using Microsoft.Xna.Framework;
using Sprint0;
using Sprint2.Block_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2.Commands
{
    public class RevealInvisibleBlocksCommand : ICommand
    {
        Game1 currentGame;
        public RevealInvisibleBlocksCommand(Game1 game) 
        {
            currentGame = game;
        }
        public void Execute(GameTime gameTime)
        {
            foreach (CollidableObject collidable in currentGame.Collidables) 
            {
                if(collidable.CollidableType == CollidableObject.Type.StandardBlock) 
                {
                    ((BlockStateMachine)collidable).Reveal();
                }
            }
        }
    }
}
