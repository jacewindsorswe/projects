﻿using Microsoft.Xna.Framework;
using Sprint2;
using Sprint2.Item_Classes;
using Sprint2.Item_Classes.ItemStates;
using Sprint2.Link_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Sprint0
{
    public class AttackSecondaryCommand : ICommand
    {
        Game1 game1;
        private int x;
        private int y;
        LinkStateMachine.Direction direction;

        Item arrow;
        Projectile arrowProj;
        
        public AttackSecondaryCommand(Game1 game)
        {
            game1 = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            ICommand command;
            switch (GlobalUtilities.ConvertHUDToItem(LinkInventory.BItem)) 
            {
                case Item.ItemCategory.Bow:
                    command = new AttackArrowLinkCommand(game1);
                    command.Execute(gameTime);
                    break;
                case Item.ItemCategory.Bomb:
                    command = new AttackBombLinkCommand(game1);
                    command.Execute(gameTime);
                    break;
                case Item.ItemCategory.Boomerang:
                    command = new AttackBoomerangLinkCommand(game1);
                    command.Execute(gameTime);
                    break;
            }

        }
    }
}
