﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Sprint2.Item_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class AttackFireLinkCommand : ICommand
    {
        Game1 game1;
        int x;
        int y;
        LinkStateMachine.Direction direction;
        Projectile fireProj;

        public AttackFireLinkCommand(Game1 game)
        {
            game1 = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            game1.link1.ShootProjectile();

            x = game1.link1.CurrentXPos;
            y = game1.link1.CurrentYPos;
            direction = game1.link1.direction;

            Item fire = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.Fire, x, y);

            switch (direction)
            {
                case (LinkStateMachine.Direction.Up):
                    fire.MovementDirection = Item.Direction.Up;
                    y -= 45;
                    break;
                case (LinkStateMachine.Direction.Down):
                    fire.MovementDirection = Item.Direction.Down;
                    y += 45;
                    break;
                case (LinkStateMachine.Direction.Left):
                    fire.MovementDirection = Item.Direction.Left;
                    x -= 45;
                    break;
                case (LinkStateMachine.Direction.Right):
                    fire.MovementDirection = Item.Direction.Right;
                    x += 45;
                    break;
            }

            fireProj = new Projectile(fire, gameTime.TotalGameTime.TotalSeconds, x, y);
            fireProj.LinkThrow = true;
            game1._soundEffectGenerator.Play("LOZ_Candle");
        }
    }
}
