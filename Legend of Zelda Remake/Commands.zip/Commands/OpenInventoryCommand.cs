﻿using Microsoft.Xna.Framework;
using Sprint2.Item_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class OpenInventoryCommand : ICommand
    {
        Game1 commandGame;

        public OpenInventoryCommand(Game1 game)
        {
            commandGame = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            Game1.GameState = Game1.GameStateType.Inventory;
        }
    }
}
