﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Sprint2;
using Sprint2.Item_Classes;
using Sprint2.Item_Classes.ItemStates;
using Sprint2.Link_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Sprint0
{
    public class AttackArrowLinkCommand : ICommand
    {
        Game1 game1;
        private int x;
        private int y;
        LinkStateMachine.Direction direction;

        Item arrow;
        Projectile arrowProj;
        
        public AttackArrowLinkCommand(Game1 game)
        {
            game1 = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            if (LinkInventory.Inventory[Item.ItemCategory.Rupee] > 0)
            {
                LinkInventory.SpendRupees(1);
                game1.link1.ShootProjectile();

                x = game1.link1.CurrentXPos;
                y = game1.link1.CurrentYPos;

                direction = game1.link1.direction;

                switch (direction)
                {
                    case (LinkStateMachine.Direction.Up):
                        arrow = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.UpArrow, x, y);
                        arrow.MovementDirection = Item.Direction.Up;
                        arrow.Y -= 32;
                        arrow.X += 18;
                        break;
                    case (LinkStateMachine.Direction.Down):
                        arrow = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.DownArrow, x, y);
                        arrow.MovementDirection = Item.Direction.Down;
                        arrow.Y += 45;
                        arrow.X += 18;
                        break;
                    case (LinkStateMachine.Direction.Left):
                        arrow = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.LeftArrow, x, y);
                        arrow.MovementDirection = Item.Direction.Left;
                        arrow.X -= 32;
                        arrow.Y += 15;
                        break;
                    case (LinkStateMachine.Direction.Right):
                        arrow = ItemSpriteFactory.Instance.CreateItem(Item.ItemCategory.RightArrow, x, y);
                        arrow.MovementDirection = Item.Direction.Right;
                        arrow.X += 45;
                        arrow.Y += 15;
                        break;
                }
                arrowProj = new Projectile(arrow, gameTime.TotalGameTime.TotalSeconds, arrow.X, arrow.Y);
                arrowProj.LinkThrow = true;
                game1._soundEffectGenerator.Play("LOZ_Arrow_Boomerang");
            }

        }
    }
}
