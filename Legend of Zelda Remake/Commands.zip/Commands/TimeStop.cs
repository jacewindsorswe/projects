﻿using Microsoft.Xna.Framework;
using Sprint2;
using Sprint2.Item_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    public class TimeStop : ICommand
    {
        Game1 commandGame;
        public TimeStop(Game1 game)
        {
            commandGame = game;
        }
        void ICommand.Execute(GameTime gameTime)
        {
            foreach(KeyValuePair<int, Enemy> entry in Enemy.EnemiesDictionary) 
            {
                if (entry.Value.IsActive) 
                {
                    entry.Value.Stun(Item.ItemCategory.Clock);
                    entry.Value.StunTime = gameTime.TotalGameTime.TotalSeconds;
                }
            }
        }
    }
}
